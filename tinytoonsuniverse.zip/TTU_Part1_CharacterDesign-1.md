# 🌟 TINYTOONS UNIVERSE — COMPLETE PRODUCTION PACKAGE
## MASTER DOCUMENT | CONFIDENTIAL — OWNER USE ONLY
### Version 1.0 | June 2026 | Advanced Industry-Level Professional Package

---

> **HOW TO USE THIS DOCUMENT**
> This is a ready-to-copy production package. Every prompt, script, and spec in this document can be copied directly into your phone tools (Google ImageFX, Bing Image Creator, Kling AI, Pika Labs, ElevenLabs, TTSMaker, Suno AI, CapCut).
> **READ ORDER:** Part 1 → Character Design (this file) | Part 2 → Short Videos | Part 3 → Long Video

---

# ═══════════════════════════════════════════════════════
# PART 1 — ADVANCED PROFESSIONAL CHARACTER DESIGN BIBLE
# ═══════════════════════════════════════════════════════

> **CRITICAL RULE FOR ALL AI IMAGE TOOLS:** Always use the MASTER REFERENCE PROMPT first to establish the character, then use scene-specific prompts. Never generate a character without the style descriptor: "CoComelon-quality 3D animation, chubby cartoon proportions, head-to-body ratio 1.8:1, large round expressive eyes, soft rounded edges, ultra-vibrant saturated colors, professional studio lighting, 4K render quality."

---

## ════════════════════════════════════════════════
## CHARACTER 1 — TINO STARLIGHT (English Host)
## ════════════════════════════════════════════════

### MASTER CHARACTER SPECIFICATION SHEET

```
FULL NAME      : Tino Starlight
NICKNAME       : Tino
AGE            : 5 years old
GENDER         : Boy
LANGUAGE       : English (US Primary Host)
PERSONALITY    : Curious, brave, adventurous, always laughing, loves to dance and sing
CATCHPHRASE    : "Let's do this, TinyToons style!"
SPECIAL TRAIT  : Star-shaped golden badge on left bib of overalls — his signature
MOTIVATION     : Wants to learn everything and share it with his friends
FEAR           : Nothing (he's fearless — which gets him into funny situations)
HOBBY          : Jumping, spinning, exploring, making faces at Starla to make her laugh
```

### TINO COMPLETE COLOR SYSTEM (EVERY ELEMENT LABELED)

```
┌─────────────────────────────────────────────────────────────┐
│                    TINO COLOR PALETTE                       │
├──────────────────────┬──────────────────────────────────────┤
│ ELEMENT              │ HEX CODE          │ RGB               │
├──────────────────────┼───────────────────┼───────────────────┤
│ Hair (base)          │ #FFD700           │ 255, 215, 0       │
│ Hair (highlight)     │ #FFF176           │ 255, 241, 118     │
│ Hair (shadow)        │ #F9A825           │ 249, 168, 37      │
│ Skin (base)          │ #FFCBA4           │ 255, 203, 164     │
│ Skin (highlight)     │ #FFE0C4           │ 255, 224, 196     │
│ Skin (shadow)        │ #E8A87C           │ 232, 168, 124     │
│ Rosy cheeks          │ #FF8A80           │ 255, 138, 128     │
│ Eyes (iris)          │ #5D4037           │ 93, 64, 55        │
│ Eyes (highlight)     │ #FFFFFF           │ 255, 255, 255     │
│ Eyes (pupil)         │ #1A1A1A           │ 26, 26, 26        │
│ Eye whites           │ #FAFAFA           │ 250, 250, 250     │
│ Overalls (main)      │ #1976D2           │ 25, 118, 210      │
│ Overalls (shadow)    │ #0D47A1           │ 13, 71, 161       │
│ Overalls (highlight) │ #42A5F5           │ 66, 165, 245      │
│ T-shirt (white)      │ #F5F5F5           │ 245, 245, 245     │
│ T-shirt (stripe 1)   │ #FF7043           │ 255, 112, 67      │
│ T-shirt (stripe 2)   │ #FFF9C4           │ 255, 249, 196     │
│ Star badge           │ #FFD600           │ 255, 214, 0       │
│ Star badge outline   │ #FF6F00           │ 255, 111, 0       │
│ Sneakers (base)      │ #E53935           │ 229, 57, 53       │
│ Sneaker sole         │ #FFFFFF           │ 255, 255, 255     │
│ Sneaker laces        │ #FFFFFF           │ 255, 255, 255     │
│ Lip color            │ #E57373           │ 229, 115, 115     │
│ Nose                 │ #E8A87C           │ 232, 168, 124     │
└──────────────────────┴───────────────────┴───────────────────┘
```

### TINO 3D PROPORTION GUIDE

```
HEAD-TO-BODY RATIO     : 1.8 : 1 (head is nearly twice the body height)
HEAD WIDTH             : 1.0 units (reference unit)
HEAD HEIGHT            : 0.9 units (slightly wider than tall — round)
BODY HEIGHT            : 0.55 units (compact, chubby child proportion)
SHOULDER WIDTH         : 0.7 units
ARM LENGTH (each)      : 0.4 units (slightly short — cute proportion)
HAND SIZE              : 0.18 units (chubby, rounded fingers — 4 fingers total)
LEG HEIGHT (each)      : 0.35 units
FOOT SIZE              : 0.22 units (slightly oversized — cartoonish)
EYE SIZE (each)        : 0.28 units (very large — takes up 30% of face)
EYE SPACING            : 0.32 units apart (center to center)
NOSE                   : Tiny button — 0.06 units
MOUTH (smile)          : 0.3 units wide when fully open
EAR SIZE (each)        : 0.12 units
EYEBROW THICKNESS      : 0.04 units (expressive, slightly arched)
HAIR PUFF HEIGHT       : 0.15 units above head crown (bouncy curls)
CHEEK PUFF RADIUS      : 0.12 units (rosy cheeks, slightly protruding)
```

### TINO AI IMAGE GENERATION PROMPTS — 7 ESSENTIAL VIEWS

**VIEW 1: MASTER REFERENCE — FRONT VIEW FULL BODY (Generate this FIRST)**

🖼️ IMAGE PROMPT — Copy into Google ImageFX / Bing Image Creator:
```
Professional 3D animated character design reference sheet — FRONT VIEW, FULL BODY — of Tino Starlight, a 5-year-old boy character for a CoComelon-quality kids YouTube channel called TinyToons Universe. Character specifications: golden yellow bouncy curly hair with bright highlights and slight volume on top; large round warm brown eyes with thick lashes, white catchlight at top-right of each iris; tiny button nose; rosy round cheeks with subtle pink blush; warm light tan skin tone; happy closed-mouth smile showing no teeth, pure joy expression. Outfit: bright blue denim overalls with front bib patch, white t-shirt with thin orange and yellow horizontal stripes underneath, red sneakers with white soles and white laces. A small golden star-shaped badge on the left bib of the overalls. Character proportions: very large round head relative to compact chubby body, head-to-body ratio 1.8:1, arms slightly short and chubby, 4 fingers on each hand. Character stands in a neutral T-pose facing directly forward, arms slightly away from body, feet slightly apart. White studio background. Ultra-professional 3D render quality, smooth cartoon rendering, vibrant saturated colors, sharp clean edges, CoComelon animation style. Masterpiece character sheet quality, 4K, no background elements, perfect symmetry, full body visible head to toe.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic photography, anime style, 2D flat illustration, sketch, rough edges, dark shadows, scary expression, violent, adult content, nsfw, ugly, deformed face, extra limbs, missing limbs, bad anatomy, watermark, text overlay, logo, multiple characters in one image, side view, three-quarter view, action pose, colorful background, scenery, distorted proportions, missing fingers, six fingers, asymmetric features, out of frame, cropped head, cropped feet, anatomically wrong, doll-like, poorly rendered hair
```

---

**VIEW 2: 3/4 ANGLE — SIGNATURE POSE (Use for most scenes)**

🖼️ IMAGE PROMPT:
```
Professional 3D animated CoComelon-quality character Tino Starlight, 5-year-old boy, in his signature 3/4 angle pose facing slightly left. Same exact character design: golden curly bouncy hair, large round warm brown expressive eyes, warm tan skin, rosy round cheeks, tiny button nose. Wearing blue denim overalls with golden star badge on left bib, white striped t-shirt underneath, red sneakers with white soles. Three-quarter view shows the character from front-left angle at approximately 35 degrees. POSE: both fists raised in excitement at shoulder height, elbows bent, huge open-mouth grin showing upper teeth and pure joy, eyebrows raised high in excitement, eyes squinting slightly with the big smile. Slight lean forward in the body — enthusiastic and energetic body language. White background. Ultra-vibrant saturated colors, perfect 3D render, studio lighting from slight upper left, CoComelon quality, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D flat, sketch, dark shadows, scary, violent, adult, nsfw, ugly, deformed, extra limbs, missing limbs, bad anatomy, watermark, text, logo, distorted proportions, wrong colors, missing star badge, gray overalls, wrong hair color, multiple characters, cluttered background, dark background, out of frame, cropped
```

---

**VIEW 3: SIDE PROFILE — LEFT VIEW (Use for walking/running scenes)**

🖼️ IMAGE PROMPT:
```
Professional 3D animated CoComelon-quality character Tino Starlight, 5-year-old boy, PERFECT LEFT SIDE PROFILE VIEW, exact 90-degree side view. Same character: golden curly hair (curls visible from side), large round eye visible from side with full long lashes, round rosy cheek prominent in profile, tiny button nose in profile (small upturned), warm tan skin, small cute ear visible. Blue denim overalls profile shows the bib and shoulder straps clearly, white t-shirt visible at collar and sleeves, red sneaker visible from side. POSE: walking pose — left leg forward, right leg back, corresponding arm positions, slight body lean forward suggesting motion, happy expression looking forward. White studio background, ultra-vibrant, CoComelon quality 3D, professional studio lighting, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, sketch, front view, three-quarter view, dark, scary, adult, nsfw, ugly, deformed, extra limbs, bad anatomy, watermark, text, logo, wrong colors, distorted, out of frame, cropped
```

---

**VIEW 4: CLOSE-UP FACE — EMOTION REFERENCE (Use for thumbnail creation)**

🖼️ IMAGE PROMPT:
```
Extreme close-up face portrait of 3D animated character Tino Starlight for TinyToons Universe kids channel. CoComelon quality 3D animation. Face fills 80% of the frame. Features: large round warm brown eyes with wide pupils showing PURE EXCITEMENT — eyes wide open, irises large, bright white catchlights at upper-right of each eye, thick lashes, expressive eyebrows raised high in delight. Rosy chubby cheeks prominently visible. Tiny button nose. OPEN MOUTH HUGE GRIN expression — mouth wide open showing upper teeth (4-6 rounded child teeth), jaw dropped in amazement. Golden curly hair with bouncy curls visible at top and sides. Warm tan skin. Ultra-vibrant, ultra-sharp 4K, professional studio lighting, catchlight in eyes, clean smooth 3D render, extremely emotive expression. Dark indigo background with colorful sparkles for contrast (thumbnail-ready). No watermark.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D flat, dark shadows on face, scary expression, scary eyes, ugly, deformed, extra limbs, bad anatomy, watermark, text, multiple faces, full body visible, distorted proportions, asymmetric eyes, wrong hair color, gray tone, washed out colors
```

---

**VIEW 5: EXPRESSION REFERENCE SHEET — 8 EMOTIONS (Essential for consistency)**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character Tino Starlight expression reference sheet. White background. Eight individual facial close-ups of the SAME character arranged in a clean 4x2 grid. Each face shows one specific emotion, clearly labeled with small text below. Same exact character design in all 8: golden curly hair, warm tan skin, rosy cheeks, blue overalls visible at shoulder. EMOTION 1 (top-left): PURE JOY — huge open smile, squinting happy eyes, flushed cheeks, eyebrows raised, arms reaching up. EMOTION 2: SURPRISED — mouth open O-shape, eyes huge and wide, eyebrows up high, hands on cheeks. EMOTION 3: THINKING — one eyebrow raised, looking up-right, finger on chin, small closed contemplative smile. EMOTION 4: LAUGHING — eyes fully closed in laugh crescents, mouth wide open, head tilted back. EMOTION 5: SHY/EMBARRASSED — eyes looking down-left, small closed smile, cheeks very pink, one hand behind head. EMOTION 6: DETERMINED/BRAVE — eyebrows furrowed in concentration, mouth set firm, eyes forward and focused. EMOTION 7: CRYING/SAD — big shiny teardrop tears (cute not ugly), lip quivering downward, eyebrows angled inward at center. EMOTION 8: SLEEPY — heavy half-closed eyes, tiny Zzz floating above head, small relaxed closed smile. CoComelon quality 3D render, ultra-vibrant, masterpiece quality, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, different characters in each panel, inconsistent design between panels, scary expressions, adult content, nsfw, ugly, deformed, bad anatomy, watermark, text except emotion labels, distorted, wrong hair colors, mismatched outfits between panels
```

---

**VIEW 6: ACTION POSE COLLECTION — 4 DYNAMIC POSES**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character design action pose sheet for Tino Starlight from TinyToons Universe. White background. Four dynamic full-body poses of the same character in a clean 2x2 grid. Same character: golden curly hair, tan skin, blue overalls with gold star badge, white striped t-shirt, red sneakers. POSE 1 (top-left): JUMPING — both feet off ground at peak jump height, arms spread wide, face showing open-mouth joy, curls bouncing upward. POSE 2 (top-right): DANCING — weight on left foot, right leg kicked to side, left arm up, right arm out, huge grin, body in mid-spin. POSE 3 (bottom-left): RUNNING — full sprint lean, one leg back, one forward, fists pumping, mouth open in excitement, hair streaming behind. POSE 4 (bottom-right): WAVING AT CAMERA — standing slightly turned toward viewer, one arm raised in enthusiastic wave, other hand on hip, huge happy smile, direct eye contact with viewer. CoComelon quality 3D, ultra-vibrant, professional studio lighting, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D flat, different character designs between poses, static poses, dark background, scary, adult content, nsfw, ugly, deformed, extra limbs, bad anatomy, watermark, distorted, wrong colors
```

---

**VIEW 7: OUTFIT VARIANTS — 3 LOOKS (Cultural + Seasonal)**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character design outfit variant sheet for Tino Starlight from TinyToons Universe. White background. Three full-body views of the same character in different outfits arranged horizontally. Same face, hair, and proportions in all three. OUTFIT 1 (left) — SIGNATURE/DAILY: Blue denim overalls, white striped t-shirt, red sneakers, gold star badge. OUTFIT 2 (center) — FESTIVAL/DIWALI: Traditional Indian kurta in bright royal blue with gold embroidery trim, cream pajama pants, matching blue mojri shoes with gold curled toe, small diya (lamp) motif on kurta chest, gold star badge retained. OUTFIT 3 (right) — ADVENTURE/SPACE: Mini astronaut suit in white with royal blue accent panels, gold star on chest instead of NASA logo, clear dome helmet with golden visor open/up, small rocket icon on left arm. Each outfit is vibrant, professional, child-appropriate, and maintains Tino's signature colors (blue + gold). CoComelon quality 3D render, ultra-vibrant, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, different face or hair between outfits, adult clothing, dark colors, scary, adult content, nsfw, ugly, deformed, bad anatomy, watermark, distorted, wrong hair color
```

---

## ════════════════════════════════════════════════
## CHARACTER 2 — PRIYA SUNDAR (Telugu & Tamil Host)
## ════════════════════════════════════════════════

### MASTER CHARACTER SPECIFICATION SHEET

```
FULL NAME      : Priya Sundar
NICKNAME       : Priya
AGE            : 5 years old
GENDER         : Girl
LANGUAGE       : Telugu (primary) + Tamil (secondary)
PERSONALITY    : Clever, creative, artistic, loves singing and drawing, gentle and kind
CATCHPHRASE    : "Raandi raandi! Come, let's learn together!"
SPECIAL TRAIT  : Always has a tiny orange notebook in her left hand or back pocket
MOTIVATION     : Wants to share her culture's beauty with the whole world
HOBBY          : Drawing kolam patterns, singing classical songs, feeding birds
CULTURAL NOTES : Represents South Indian culture — Tamil Nadu + Andhra Pradesh
```

### PRIYA COMPLETE COLOR SYSTEM

```
┌─────────────────────────────────────────────────────────────┐
│                   PRIYA COLOR PALETTE                       │
├──────────────────────┬──────────────────────────────────────┤
│ ELEMENT              │ HEX CODE          │ RGB               │
├──────────────────────┼───────────────────┼───────────────────┤
│ Hair (base)          │ #1A1A2E           │ 26, 26, 46        │
│ Hair (highlight)     │ #3A3A5C           │ 58, 58, 92        │
│ Hair bow 1 (left)    │ #FFD600           │ 255, 214, 0       │
│ Hair bow 2 (right)   │ #FFD600           │ 255, 214, 0       │
│ Skin (base)          │ #D4956A           │ 212, 149, 106     │
│ Skin (highlight)     │ #E8B48A           │ 232, 180, 138     │
│ Skin (shadow)        │ #B8784E           │ 184, 120, 78      │
│ Rosy cheeks          │ #FF6B9D           │ 255, 107, 157     │
│ Eyes (iris)          │ #3E2723           │ 62, 39, 35        │
│ Eyes (highlight)     │ #FFFFFF           │ 255, 255, 255     │
│ Eyes (pupil)         │ #0D0D0D           │ 13, 13, 13        │
│ Eye liner (kohl)     │ #2D1B12           │ 45, 27, 18        │
│ Outfit pink (main)   │ #E91E63           │ 233, 30, 99       │
│ Outfit pink (shadow) │ #C2185B           │ 194, 24, 91       │
│ Dupatta yellow       │ #FFD600           │ 255, 214, 0       │
│ Outfit trim gold     │ #FF8F00           │ 255, 143, 0       │
│ Bindi               │ #F44336           │ 244, 67, 54       │
│ Tiny earrings        │ #FFD700           │ 255, 215, 0       │
│ Notebook cover       │ #FF6D00           │ 255, 109, 0       │
│ Crayon (held)        │ #4CAF50           │ 76, 175, 80       │
│ Sandals              │ #FF8F00           │ 255, 143, 0       │
└──────────────────────┴───────────────────┴───────────────────┘
```

### PRIYA KEY VISUAL DISTINCTION FEATURES

```
PIGTAILS STRUCTURE  : Two identical pigtails, symmetrical — starting at exactly
                      ear height on both sides, pulled tight then flowing down
                      in gentle S-curves to below shoulder level. Slight natural
                      wave to hair, not perfectly straight. Each pigtail held
                      with a large yellow bow (ribbon style, not ball style).

BINDI               : Small classic round red bindi centered precisely between
                      and slightly above eyebrow line. Always present in all scenes.

KOHL EYES           : Slightly darker ring around the outer edge of each eye
                      (like kajal/kohl effect) — makes eyes look even larger
                      and more expressive. Signature cultural feature.

DIMPLES             : Two symmetrical dimples appear ONLY when Priya smiles broadly.
                      Located at corners of mouth. Very characteristic — makes
                      her smile immediately recognizable.

TINY EARRINGS       : Small gold circular studs, always visible. Subtle but present.

NOTEBOOK            : Small orange notebook (A6 size), often tucked in waist of
                      salwar OR held in left hand. Has TinyToons star sticker on cover.
```

### PRIYA AI IMAGE GENERATION PROMPTS — 6 ESSENTIAL VIEWS

**VIEW 1: MASTER REFERENCE — FRONT VIEW FULL BODY**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character design reference sheet — FRONT VIEW, FULL BODY — of Priya Sundar, a 5-year-old Indian girl character for TinyToons Universe kids YouTube channel, CoComelon-quality 3D animation. Character specifications: jet-black hair neatly divided into two long pigtails tied with large yellow ribbon bows at ear height on each side; very large dark brown almond-shaped eyes with long lashes and subtle kohl (kajal) ring for depth, warm white eye catchlights; small red round bindi precisely placed above and between eyebrows; small gold circular earring studs; warm medium-brown skin with golden undertone, pink blush on round chubby cheeks, dimpled when smiling; small upturned nose. OUTFIT: bright pink Indian salwar kameez (tunic top with side slits, comfortable trousers) with golden embroidery trim at neckline, hemline and cuffs; bright yellow dupatta (shawl) draped over left shoulder; golden-orange flat sandals with decorative toe ring design. Small orange notebook visible in left hand. Neutral standing pose facing directly forward, slight happy smile (dimples visible), arms relaxed at sides with notebook in left hand. White studio background. Head-to-body ratio 1.8:1, chubby cartoon proportions, ultra-vibrant saturated colors, CoComelon 3D quality, masterpiece character sheet, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic photography, anime style, 2D flat illustration, sketch, scary expression, violent, adult content, nsfw, ugly, deformed face, extra limbs, missing limbs, bad anatomy, watermark, text overlay, logo, multiple characters, side view, action pose, colorful background, distorted proportions, wrong skin tone, missing bindi, western outfit, inappropriate clothing for a child, revealing clothing, dark background, out of frame, cropped, asymmetric pigtails
```

---

**VIEW 2: EXPRESSIVE 3/4 ANGLE — SINGING POSE**

🖼️ IMAGE PROMPT:
```
Professional 3D animated CoComelon-quality character Priya Sundar, 5-year-old Indian girl from TinyToons Universe, in a beautiful 3/4 angle singing pose. Three-quarter view facing slightly right. Same exact character: jet-black pigtails with large yellow bows, large dark kohl-lined almond eyes, small red bindi, medium-brown warm skin, pink chubby cheeks with dimples, golden earring studs. Pink salwar with yellow dupatta draped over left shoulder, golden sandals. POSE: mouth gently open in song — a soft O shape suggesting melodious singing, both hands clasped at chest in a heartfelt singing gesture, head slightly tilted upward looking dreamily toward sky-upper-left direction, eyes soft and shining with joy, eyebrows gently raised. Body weight slightly on right foot, left knee slightly bent, graceful and gentle posture suggesting classical Indian singing style. Colorful gradient background in pink and yellow tones. Ultra-vibrant, CoComelon 3D quality, professional studio lighting, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed, extra limbs, bad anatomy, watermark, text, logo, wrong skin tone, missing bindi, missing bow, distorted proportions, wrong outfit colors, open-mouth yelling expression, stiff pose
```

---

**VIEW 3: CLOSE-UP FACE — THUMBNAIL READY**

🖼️ IMAGE PROMPT:
```
Extreme close-up face portrait of 3D animated character Priya Sundar from TinyToons Universe for thumbnail creation, CoComelon quality. Face fills 80% of frame. Large dark kohl-lined almond eyes fully open with DELIGHTED SURPRISE expression — irises very dark brown, long lashes swept upward, bright white teardrop catchlight in each eye, eyebrows raised high in delight. Small red round bindi centered above eyebrow line. Chubby warm brown cheeks with pink blush flush. Gold earring studs catching light. Pigtails with yellow bows visible at frame sides. Mouth open in a beautiful surprised smile — showing slightly parted lips, upper teeth visible, dimples deeply present on both cheeks. Warm golden studio lighting, catchlight in eyes, ultra-vibrant, sharp 4K. Bright gradient background: warm pink fading to yellow — thumbnail-ready composition. No watermark.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, scary expression, adult, nsfw, ugly, deformed, bad anatomy, watermark, wrong skin tone, missing bindi, missing earrings, asymmetric eyes, flat expression, dark background, washed out colors
```

---

**VIEW 4: CULTURAL OUTFIT VARIANTS — 3 LOOKS**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character design outfit variant sheet for Priya Sundar from TinyToons Universe. White background. Three full-body views of the same character horizontally arranged. Same face, hair, and proportions in all three. OUTFIT 1 (left) — SIGNATURE/DAILY: Bright pink salwar kameez with yellow dupatta and gold trim, golden sandals, orange notebook in hand. OUTFIT 2 (center) — PONGAL/FESTIVAL: Traditional Kanchipuram-style silk pavadai (skirt) in rich magenta with gold zari border, matching silk blouse in gold, fresh jasmine flowers (mallipoo garland) woven into hair alongside yellow bows, traditional gold necklace and bangles, colorful kolam pattern drawn at her feet. OUTFIT 3 (right) — CLASSICAL DANCE/BHARATANATYAM PRACTICE: Bharatanatyam-style costume in orange-red silk with gold border, traditional dance jewelry (temple necklace, armlets, anklets), hair in a tight bun with gold hairpin and yellow chrysanthemum, classic dance mudra pose (one hand raised in Katakamukha). All outfits maintain Priya's signature pink+gold+yellow palette. CoComelon quality 3D render, ultra-vibrant, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, inconsistent face between outfits, inappropriate clothing, adult clothing, dark colors, scary, nsfw, ugly, deformed, bad anatomy, watermark, wrong skin tone, missing bindi across all outfits
```

---

**VIEW 5: ACTION POSES — 4 DYNAMICS**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character action pose sheet for Priya Sundar from TinyToons Universe. White background. Four dynamic full-body poses in a 2x2 grid. Consistent character design across all. POSE 1 (top-left): DRAWING KOLAM — crouching down with legs bent, leaning forward, right hand moving across floor as if drawing a pattern, face concentrated with tongue slightly out in concentration, notebook open beside her. POSE 2 (top-right): CLAPPING AND SINGING — both hands clapping above head, eyes closed in pure musical joy, head tilted back, big smile showing dimples, dupatta flowing with motion. POSE 3 (bottom-left): POINTING AND TEACHING — index finger pointing up in a "did you know?" teaching gesture, other hand on hip, confident expression with slight smile, direct eye contact suggesting she's talking to the viewer. POSE 4 (bottom-right): FEEDING BIRDS — kneeling gently with palm held flat outward, tiny birds approaching her hand (2 small cartoon birds), expression of absolute gentle wonder and joy. CoComelon quality 3D, ultra-vibrant, professional studio lighting, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, inconsistent character design, dark, scary, adult, nsfw, ugly, deformed, extra limbs, bad anatomy, watermark, distorted, wrong colors, wrong skin tone
```

---

## ════════════════════════════════════════════════
## CHARACTER 3 — ARJUN VEER (Hindi & Odia Host)
## ════════════════════════════════════════════════

### MASTER CHARACTER SPECIFICATION SHEET

```
FULL NAME      : Arjun Veer
NICKNAME       : Arjun
AGE            : 6 years old (oldest of the main trio)
GENDER         : Boy
LANGUAGE       : Hindi (primary) + Odia (secondary)
PERSONALITY    : Energetic, sporty, loves being the hero, acts first thinks later, loyal
CATCHPHRASE    : "Ek dum mast! That was AMAZING!"
SPECIAL TRAIT  : A small "A" embroidered logo on his kurta chest or tracksuit
MOTIVATION     : Wants to be the best at everything — especially sports and dancing
HOBBY          : Football, cricket, traditional wrestling (Kushti), bhangra dancing
FLAW           : Gets so excited he sometimes trips over his own feet (endearing comedy)
```

### ARJUN COMPLETE COLOR SYSTEM

```
┌─────────────────────────────────────────────────────────────┐
│                   ARJUN COLOR PALETTE                       │
├──────────────────────┬──────────────────────────────────────┤
│ ELEMENT              │ HEX CODE          │ RGB               │
├──────────────────────┼───────────────────┼───────────────────┤
│ Hair (base)          │ #212121           │ 33, 33, 33        │
│ Hair (highlight)     │ #424242           │ 66, 66, 66        │
│ Hair side parting    │ #1A1A1A           │ 26, 26, 26        │
│ Skin (base)          │ #8D5524           │ 141, 85, 36       │
│ Skin (highlight)     │ #A0522D           │ 160, 82, 45       │
│ Skin (shadow)        │ #6D4C41           │ 109, 76, 65       │
│ Eyes (iris)          │ #2E2215           │ 46, 34, 21        │
│ Eyes (highlight)     │ #FFFFFF           │ 255, 255, 255     │
│ Rosy cheeks          │ #FF7043           │ 255, 112, 67      │
│ Kurta orange (main)  │ #FF6D00           │ 255, 109, 0       │
│ Kurta (highlight)    │ #FF8F00           │ 255, 143, 0       │
│ Kurta (shadow)       │ #E64A19           │ 230, 74, 25       │
│ Kurta embroid. gold  │ #FFD600           │ 255, 214, 0       │
│ Pajama (cream)       │ #FFF8E1           │ 255, 248, 225     │
│ Sports tracksuit grn │ #388E3C           │ 56, 142, 60       │
│ Track stripe yellow  │ #FFD600           │ 255, 214, 0       │
│ Shoes (brown/tan)    │ #795548           │ 121, 85, 72       │
│ Lip color            │ #D84315           │ 216, 67, 21       │
│ "A" emblem color     │ #FFD600           │ 255, 214, 0       │
└──────────────────────┴───────────────────┴───────────────────┘
```

### ARJUN KEY VISUAL DISTINCTION FEATURES

```
HAIR STYLE      : Short black hair with a natural side parting — very neat on top
                  but slightly tousled at the ends suggesting energy and activity.
                  Never perfectly flat — always has a slight bounce/energy to it.

ATHLETIC BUILD  : Slightly stockier and broader-shouldered than Tino — suggesting
                  he is older and more physically active. Still child-proportion.

SIGNATURE SMIRK : Arjun's default expression is a confident half-smile with one
                  eyebrow slightly raised — the look of someone about to say "watch
                  this!" Very distinct from Tino's pure open joy smile.

"A" EMBLEM      : Small gold embroidered letter "A" (in a stylized sports font) on
                  left chest of both his kurta AND his tracksuit. Always present.

ENERGY LINES    : In highly active scenes, small yellow motion lines (speed lines)
                  can appear around him briefly suggesting dynamic energy.

EXPRESSION TELL : When Arjun is embarrassed (after falling or messing up), his
                  cheeks go VERY orange-red (his cheek blush intensifies dramatically)
                  — funnier and more noticeable than other characters.
```

### ARJUN AI IMAGE GENERATION PROMPTS — 5 ESSENTIAL VIEWS

**VIEW 1: MASTER REFERENCE — FRONT VIEW FULL BODY**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character design reference sheet — FRONT VIEW, FULL BODY — of Arjun Veer, a 6-year-old Indian boy character for TinyToons Universe kids YouTube channel, CoComelon-quality 3D animation. Character: short neat black hair with natural side parting, slight tousle at ends; large dark brown eyes with bright white catchlights; slightly broader shoulders and stockier build than a typical 5-year-old, warm dark brown skin tone, orange-tinted round cheeks, confident half-smile with one eyebrow slightly raised (signature smirk). OUTFIT: bright orange traditional kurta with gold embroidery at neckline and cuffs, small gold "A" emblem on left chest; cream-colored pajama trousers; light tan mojri shoes with slightly pointed toe. Neutral standing pose facing directly forward, arms relaxed at sides, confident weight distribution — one hip slightly forward. White studio background. Head-to-body ratio 1.8:1, chubby cartoon proportions, ultra-vibrant saturated colors, CoComelon 3D animation quality, masterpiece character sheet, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic photography, anime, 2D flat, sketch, scary, violent, adult, nsfw, ugly, deformed, extra limbs, missing limbs, bad anatomy, watermark, text, logo, multiple characters, side view, action pose, colorful background, distorted proportions, wrong skin tone, missing "A" emblem, wrong outfit color (not orange), out of frame, cropped
```

---

**VIEW 2: DUAL OUTFIT REFERENCE — KURTA + TRACKSUIT**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character design dual outfit comparison for Arjun Veer from TinyToons Universe. White background. Two full-body views of the same character side by side. Same face, hair, and proportions in both. LEFT FIGURE: KURTA OUTFIT — bright orange Indian kurta with gold embroidery, cream pajama, tan mojri shoes, gold "A" on chest. Posed with arms crossed in a confident hero stance, chin up, confident smirk. RIGHT FIGURE: SPORTS TRACKSUIT — vibrant forest green tracksuit with yellow racing stripe down each arm and leg, white t-shirt underneath, white sports sneakers, small yellow "A" logo on left chest of tracksuit jacket. Posed in a ready athlete stance — feet apart, knees slightly bent, fists raised at chest level, huge competitive grin, eyebrows furrowed in focus. Both outfits maintain orange and green as Arjun's signature colors with gold accent. CoComelon quality 3D render, ultra-vibrant, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, inconsistent face between two figures, adult clothing, dark palette, scary, nsfw, ugly, deformed, bad anatomy, watermark, wrong skin tone, missing "A" emblem, distorted
```

---

**VIEW 3: EXPRESSION + EMOTION REFERENCE**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character expression reference sheet for Arjun Veer from TinyToons Universe. White background. Six facial close-ups arranged in a 3x2 grid, same character in all panels. PANEL 1: CONFIDENT HERO — chin raised, eyes forward, one eyebrow up, signature smirk, arms crossed (shoulders visible). PANEL 2: FULL LAUGH — head thrown back, mouth wide open, eyes completely closed in laughter crescents, cheeks very puffed and orange-red. PANEL 3: SUPER EMBARRASSED — both hands covering face, peeking through fingers with one eye, face very dark orange-red blush, looking down. PANEL 4: COMPETITIVE FOCUS — eyes narrowed to intense slits, jaw set, eyebrows deeply furrowed, mouth tight small line, like a child totally focused on winning. PANEL 5: AMAZED — jaw dropped completely, eyes perfectly round and huge, both hands on cheeks (Home Alone style), shocked disbelief. PANEL 6: TIRED BUT HAPPY — eyes half-closed and drooping, lazy big smile, one thumb up, sweating slightly (tiny bead of sweat above brow) after finishing something hard. CoComelon quality 3D render, ultra-vibrant, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, inconsistent design between panels, scary expressions, adult, nsfw, ugly, deformed, bad anatomy, watermark, wrong skin tone
```

---

## ════════════════════════════════════════════════
## CHARACTER 4 — STARLA (Baby Mascot — ALL Languages)
## ════════════════════════════════════════════════

### MASTER CHARACTER SPECIFICATION SHEET

```
FULL NAME      : Starla (no last name — she's a baby!)
AGE            : Approximately 1 year old
GENDER         : Baby girl (ambiguous enough to appeal to all)
LANGUAGE       : NON-SPEAKING — communicates only through sounds, giggles, expressions
PERSONALITY    : Reaction machine — giggles at everything, cries dramatically, claps
                 enthusiastically, surprised by EVERYTHING, loves music instantly
CATCHPHRASE    : [None — only sounds: giggle, gasp, "aaaa!", "eeee!", baby sounds]
SPECIAL TRAIT  : A single curl of hair stands up on top of her otherwise bald head
MOTIVATION     : Pure joy — Starla just exists and reacts to the world with wonder
VIRAL FUNCTION : Starla IS the secret weapon. Babies reacting to things = viral
RULE           : Starla NEVER speaks words. Only sounds. Never changes her onesie
                 color. Always in the yellow star-print onesie.
```

### STARLA COMPLETE COLOR SYSTEM

```
┌─────────────────────────────────────────────────────────────┐
│                  STARLA COLOR PALETTE                       │
├──────────────────────┬──────────────────────────────────────┤
│ ELEMENT              │ HEX CODE          │ RGB               │
├──────────────────────┼───────────────────┼───────────────────┤
│ Skin (base)          │ #FFD5B0           │ 255, 213, 176     │
│ Skin (highlight)     │ #FFE8CC           │ 255, 232, 204     │
│ Skin (shadow)        │ #F0B88A           │ 240, 184, 138     │
│ Single curl (hair)   │ #8B4513           │ 139, 69, 19       │
│ Chubby cheeks blush  │ #FF8FAB           │ 255, 143, 171     │
│ Eyes (iris)          │ #4A2C0A           │ 74, 44, 10        │
│ Eye whites           │ #FEFEFE           │ 254, 254, 254     │
│ Eye catchlight       │ #FFFFFF           │ 255, 255, 255     │
│ Onesie base yellow   │ #FFD600           │ 255, 214, 0       │
│ Star prints on onesie│ #FF8F00           │ 255, 143, 0       │
│ Onesie snap bottom   │ #FFB300           │ 255, 179, 0       │
│ Baby booties         │ #FFFFFF           │ 255, 255, 255     │
│ Bootie star detail   │ #FFD600           │ 255, 214, 0       │
│ Teardrop (when cry)  │ #B3E5FC           │ 179, 229, 252     │
│ Blush (happy)        │ #FF8FAB           │ 255, 143, 171     │
│ Blush (excited)      │ #FF4081           │ 255, 64, 129      │
└──────────────────────┴───────────────────┴───────────────────┘
```

### STARLA CRITICAL PROPORTION GUIDE

```
HEAD SIZE              : ENORMOUS — head is 2.2x the body height (baby proportion)
BODY                   : Tiny egg-shaped torso, almost no neck
CHEEKS                 : Very prominent — chubby cheeks take up nearly 40% of face width
EYES                   : HUGE — teardrop shaped, larger proportion than any other character
SINGLE CURL            : The one curl on her head is roughly 15% of head height above crown
HANDS                  : Tiny chubby starfish hands — very round fingers, always open
FEET                   : Chubby rounded feet in white booties — barely visible under onesie
MOVEMENT               : All movements are slow, wobbly, unsteady — authentic baby physics
NOTE                   : Starla CANNOT stand independently — always seated, in car seat,
                         being carried, or sitting on floor/ground.
```

### STARLA AI IMAGE GENERATION PROMPTS — 5 ESSENTIAL VIEWS

**VIEW 1: MASTER REFERENCE — FRONT VIEW (SEATED)**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character design reference sheet — FRONT VIEW, FULL BODY, SEATED — of Starla, a baby mascot approximately 1 year old for TinyToons Universe kids YouTube channel, CoComelon-quality 3D animation. Character specifications: completely bald head except for exactly ONE single cute brown curl standing upright at the very top center of the head; enormous round dark-toned eyes with huge bright white teardrop catchlights, very thick lashes, eyes taking up 35% of face height; extremely chubby round cheeks with prominent pink blush — cheeks so chubby they seem to squish the nose from both sides; tiny upturned button nose barely visible; small neutral mouth in a relaxed happy baby expression. OUTFIT: bright sunshine yellow onesie covered in small orange star print pattern, white snap buttons visible along inside leg, white soft baby booties with small yellow star detail. POSE: seated on floor with legs out in front in a baby V-sit, both chubby hands resting on floor beside hips, palms flat. HEAD-TO-BODY RATIO: approximately 2.2:1 (enormous head is signature baby proportion). White studio background. CoComelon quality 3D, ultra-vibrant saturated colors, maximum cute factor, ultra-chubby proportions, 4K masterpiece character sheet.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D flat, sketch, scary expression, violent, adult, nsfw, ugly, deformed, extra limbs, bad anatomy, watermark, text, logo, standing pose (baby cannot stand alone), multiple hair curls (only ONE curl allowed), wrong onesie color, blue onesie, pink onesie, missing star prints on onesie, distorted proportions, not chubby enough, thin face, normal-sized head, out of frame, cropped, adult face features
```

---

**VIEW 2: VIRAL REACTION EXPRESSIONS — THE STARLA SHEET**

🖼️ IMAGE PROMPT:
```
Professional 3D animated character expression reference sheet for Starla baby from TinyToons Universe. White background. Six seated facial close-ups in a 3x2 grid — same character in all panels. PANEL 1: MAXIMUM JOY GIGGLE — eyes completely squeezed shut in happy crescents, tiny mouth open in a wide toothless baby giggle, both tiny fists raised and pumping, cheeks SO chubby they push eyes up. PANEL 2: SHOCKED GASP — eyes suddenly blown ENORMOUS like saucers, mouth dropped into a perfect round O, cheeks puffed, hands pressed to both cheeks (baby version). PANEL 3: DRAMATIC BABY CRY — mouth wide open in giant cartoon cry O-shape, lower lip pushed out in extreme pout, two perfectly round blue sparkly teardrop tears rolling down chubby cheeks, eyebrows angled up at center, arms raised demanding to be picked up. PANEL 4: FOCUSED ON FOOD — intense cross-eyed concentration staring at something being held toward her, tiny hand reaching forward, mouth slightly open drooling one tiny sparkle drool drop. PANEL 5: STARLA CLAPPING — palms clapping together in front of chest, huge toothless open-mouth smile, eyes bright with delight, one foot kicking up. PANEL 6: SLEEPY DROOPY — heavy eyelids at half-mast, mouth in small contented O, one single small Zzz bubble above head, slightly tilted head. CoComelon quality 3D, ultra-vibrant, maximum cute factor, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic, anime, 2D, inconsistent design between panels, scary baby, crying that looks distressed (must stay cute and comedic), adult, nsfw, ugly, deformed, bad anatomy, watermark, multiple curls (only ONE per panel), wrong onesie color, not chubby enough, thin baby face
```

---

## ══════════════════════════════════════════════
## ALL CHARACTERS TOGETHER — GROUP REFERENCE
## ══════════════════════════════════════════════

**OFFICIAL GROUP SHOT — THE TINYTOONS UNIVERSE FAMILY**

🖼️ IMAGE PROMPT:
```
Official professional 3D animated group character art for TinyToons Universe kids YouTube channel, CoComelon quality. Four characters arranged in a colorful, energetic group composition on a bright gradient background (deep indigo #4F46E5 at top, rich violet #7C3AED at bottom, golden sparkle particles throughout). FROM LEFT TO RIGHT: ARJUN VEER (6-year-old boy, short black hair with side parting, warm dark brown skin, orange kurta with gold "A" emblem, cream pajama, confident smirk with one eyebrow raised, arms crossed), PRIYA SUNDAR (5-year-old Indian girl, jet-black pigtails with yellow bows, medium warm-brown skin, red bindi, pink salwar with yellow dupatta, gold earrings, joyful open smile showing dimples, notebook in left hand), TINO STARLIGHT (5-year-old boy, golden curly hair, light tan skin, blue denim overalls with gold star badge, white striped t-shirt, red sneakers, huge open-mouth grin, arms spread wide), STARLA (baby, bald with one curl, enormous eyes, yellow star-print onesie, seated and reaching up toward camera with both tiny hands, toothless giggle). All four characters interacting naturally — Arjun and Tino high-fiving, Priya pointing and laughing, Starla reaching up with joy. Bold golden 3D bubble text "TinyToons Universe" arcs over the group at the top with sparkle effects. All character heights correctly scaled: Arjun tallest, Tino and Priya same height, Starla seated much smaller. Ultra-vibrant, ultra-saturated, professional CoComelon-quality 3D render, cinematic group composition, studio lighting, masterpiece, 4K.
```

🚫 NEGATIVE PROMPT:
```
blurry, low quality, realistic photography, anime, 2D flat, sketch, scary expressions, violent, adult content, nsfw, ugly, deformed faces, extra limbs, missing limbs, bad anatomy, watermark, wrong character colors, mismatched styles between characters, inconsistent 3D rendering quality across characters, dark ominous background, distorted proportions, missing characters, extra characters beyond the four, out of frame
```

---

## ═══════════════════════════════════
## UNIVERSAL IMAGE QUALITY STANDARDS
## ═══════════════════════════════════

### THESE PHRASES MUST APPEAR IN EVERY SINGLE IMAGE PROMPT

```
ALWAYS ADD TO IMAGE PROMPTS:
"CoComelon-quality 3D animation style, smooth cartoon rendering with rounded edges,
child-friendly proportions, ultra-vibrant saturated colors, professional studio
lighting, soft warm key light from upper-left, no harsh shadows, clean background,
masterpiece quality, 4K resolution, ultra-sharp, no motion blur, no grain"

ALWAYS ADD TO NEGATIVE PROMPTS:
"blurry, low quality, realistic photography, anime style, 2D flat illustration,
sketch, rough edges, dark ominous shadows, scary expression, violent content, adult
content, nsfw, ugly face, deformed face, extra limbs, missing limbs, bad anatomy,
watermark, text overlay, logo clutter, multiple characters when only one intended,
distorted proportions, out of frame, cropped head, anatomically wrong, doll-like
stiffness, poorly rendered hair, muted washed-out colors, gray tones"
```

---

*END OF PART 1 — CHARACTER DESIGN BIBLE*
*Continue to Part 2: Short Video 1 and Short Video 2*
*Continue to Part 3: Long Video + Editing Timelines + Metadata*
