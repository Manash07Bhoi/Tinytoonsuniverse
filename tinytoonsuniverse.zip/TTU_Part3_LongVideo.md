# 🦕 TINYTOONS UNIVERSE — PART 3: LONG VIDEO PRODUCTION PACKAGE
## "THE RAINBOW DINOSAUR PARADE! 🌈🦕" — COMPLETE INDUSTRY-LEVEL PACKAGE
## CONFIDENTIAL — OWNER USE ONLY | June 2026

---

# ═══════════════════════════════════════════════════════════
# LONG VIDEO — "THE RAINBOW DINOSAUR PARADE! 🌈🦕"
# ═══════════════════════════════════════════════════════════

## COMPLETE VIDEO OVERVIEW

```
┌──────────────────────────────────────────────────────────────────┐
│              LONG VIDEO — COMPLETE OVERVIEW CARD                 │
├───────────────────────────┬──────────────────────────────────────┤
│ Full Title                │ The Rainbow Dinosaur Parade! 🌈🦕   │
│                           │ Colors Song | TinyToons Universe     │
├───────────────────────────┼──────────────────────────────────────┤
│ Language                  │ English (US Primary)                 │
│ Format                    │ Long Video — Horizontal 16:9, 4K     │
│ Duration                  │ 4 minutes 00 seconds                 │
│ Target Age                │ 2–8 years                            │
│ Upload Day                │ Week 1 — Day 1 (Monday)              │
│                           │ Prime time: 2:00 PM EST              │
├───────────────────────────┼──────────────────────────────────────┤
│ Characters — Kids         │ Tino Starlight (English host, main)  │
│                           │ Priya Sundar (supporting)            │
│                           │ Arjun Veer (supporting)              │
│                           │ Starla (baby mascot — reactions)     │
├───────────────────────────┼──────────────────────────────────────┤
│ Characters — Dinosaurs    │ RED REX — T-Rex, vivid red, stompy  │
│ (ORIGINAL characters)     │ BLUE BELLA — Brachiosaurus, gentle  │
│                           │ GREEN GIZMO — Triceratops, bouncy   │
├───────────────────────────┼──────────────────────────────────────┤
│ Setting                   │ A magical Rainbow Jungle — lush,     │
│                           │ vibrant, colorful prehistoric forest │
├───────────────────────────┼──────────────────────────────────────┤
│ CLIP CALCULATION          │ 4:00 min = 240 sec ÷ 8 sec = 30 main│
│                           │ + 5 buffer clips = 35 TOTAL CLIPS    │
├───────────────────────────┼──────────────────────────────────────┤
│ Music Style               │ 125 BPM, G Major, Adventurous kids  │
│                           │ pop — brass fanfare, playful drums,  │
│                           │ xylophone melody, children's choir   │
│ Voice Casting             │ ElevenLabs "Lily" (Tino) + "Sarah"  │
│                           │ (Priya, Bella) + "Daniel" (Arjun)   │
├───────────────────────────┼──────────────────────────────────────┤
│ Educational Values        │ 3 colors (RED, BLUE, GREEN)          │
│                           │ Counting 1-2-3                       │
│                           │ 3 types of dinosaurs                 │
│                           │ Physical movement (stomp, sway,      │
│                           │ bounce) — body learning              │
│                           │ Positive emotions: joy, pride, awe   │
├───────────────────────────┼──────────────────────────────────────┤
│ Shorts Cut Points         │ CUT 1: 0:40-1:12 — "Red Rex Roar"  │
│ (Cut 3–5 Shorts from this)│ CUT 2: 1:12-1:52 — "Blue Bella"    │
│                           │ CUT 3: 2:12-2:48 — "Green Gizmo"   │
│                           │ CUT 4: 3:12-3:32 — "Count 1-2-3"   │
│                           │ CUT 5: 3:32-4:00 — "Grand Finale"  │
└───────────────────────────┴──────────────────────────────────────┘
```

---

## DINOSAUR CHARACTER DESIGN SPECIFICATIONS (ORIGINALS)

### RED REX — COMPLETE DESIGN BRIEF

```
┌────────────────────────────────────────────────────────┐
│               RED REX — CHARACTER SPECS                │
├──────────────────┬─────────────────────────────────────┤
│ Dinosaur Type    │ T-Rex (Tyrannosaurus Rex)            │
│ Body Color       │ Vivid Red #FF1744 (main body)        │
│ Shadow/Depth     │ Deep Red #C62828 (underside, folds)  │
│ Highlight        │ Hot Pink #FF80AB (top of back, nose) │
│ Eye Color        │ Bright Yellow #FFD600 (iris)         │
│ Teeth            │ Rounded white, friendly, NOT sharp   │
│ Special Feature  │ Crown of tiny red hibiscus flowers   │
│                  │ sitting on his head like a garland   │
│ Scale Pattern    │ Small golden star-shaped scales      │
│                  │ along back (matching Tino's badge)   │
│ Size             │ 8x the height of the kid characters  │
│ Proportions      │ Very round belly, stubby arms, big   │
│                  │ round head — NOT scary, very cute    │
│ Expression       │ Default: huge toothy friendly grin   │
│ Tail             │ Short and round at tip — like a club │
│ Personality      │ Big, loud, proud — but has a soft    │
│                  │ heart and loves hugs (he's just big) │
└──────────────────┴─────────────────────────────────────┘
```

**RED REX MASTER IMAGE PROMPT (Generate BEFORE any Red Rex scenes):**
```
Professional 3D animated character design reference sheet of RED REX, an original
T-Rex dinosaur character for TinyToons Universe kids channel. FRONT VIEW, FULL BODY.
Character specifications: extremely vivid red (#FF1744) body color from snout to tail
tip — saturated and bright, not dark; small golden star-shaped scale patterns along
the back and upper body; large round bright yellow cartoon eyes with wide black pupils
and white star-shaped catchlights; wide friendly mouth showing 8 rounded blunt white
teeth (not sharp, not scary — friendly cartoon style); tiny red crown made of small
hibiscus flowers sitting on top of his head; very round chubby belly lighter in
tone; very short stubby arms (T-Rex proportion) each ending in 3 rounded cartoon
claws; large thick legs with 3-toed feet; tail is thick and round at the tip. SIZE:
enormous compared to any human children characters — approximately 8 times the height.
PROPORTIONS: very round and chubby — not realistic; cartoon-exaggerated large head,
short body, big rounded belly. Mood: joyful and friendly — not scary whatsoever.
White studio background. CoComelon 3D animation quality, ultra-vibrant red saturation,
professional studio lighting, masterpiece character sheet, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic dinosaur, scary teeth, sharp fangs, dark colors,
aggressive expression, violent, adult, nsfw, ugly, deformed, extra limbs, bad
anatomy, watermark, 2D illustration, anime, horror aesthetic, dark shadows,
small character (must be enormous), thin proportions, anatomically correct dinosaur
(must be cartoonish), muted red colors, brown or gray dinosaur, realistic scales
```

---

### BLUE BELLA — COMPLETE DESIGN BRIEF

```
┌────────────────────────────────────────────────────────┐
│              BLUE BELLA — CHARACTER SPECS              │
├──────────────────┬─────────────────────────────────────┤
│ Dinosaur Type    │ Brachiosaurus (long-neck dinosaur)   │
│ Body Color       │ Ocean Blue #1565C0 (upper body)      │
│ Belly Color      │ Sky Blue #90CAF9 (soft belly/throat) │
│ Highlight        │ Ice Blue #E3F2FD (back highlights)   │
│ Eye Color        │ Warm Amber #FF8F00 (large oval eyes) │
│ Lashes           │ Very long and curved (princess-like) │
│ Special Feature  │ String of white jasmine flower beads │
│                  │ draped like a necklace on neck base  │
│ Tail Feature     │ Blue butterfly-shaped bow at tail tip│
│ Size             │ Tallest character — neck reaches sky │
│ Body             │ Long elegant neck, graceful posture  │
│ Expression       │ Default: serene, gentle closed smile │
│ Personality      │ Graceful, wise, loves the ocean and  │
│                  │ waterfalls, speaks very gently        │
└──────────────────┴─────────────────────────────────────┘
```

**BLUE BELLA MASTER IMAGE PROMPT:**
```
Professional 3D animated character design reference of BLUE BELLA, an original
Brachiosaurus dinosaur character for TinyToons Universe. FULL BODY, SIDE-SLIGHTLY-
3/4 VIEW to show the long neck gracefully. Ocean blue (#1565C0) upper body
transitioning to soft sky blue (#90CAF9) belly and throat; ice blue highlights on
back ridge; very large warm amber oval eyes with dramatically long curved lashes
(princess-style, very full and luxurious); serene gentle closed-mouth smile; a
graceful string of white cartoon jasmine flower beads looped around the base of
her long neck like a natural garland-necklace; a bright blue butterfly-bow at the
very tip of her tail. Long elegant neck curves naturally upward in a graceful S
shape. Four pillar-like legs with round 3-toed feet. Enormously tall — top of
neck would be far above any kid character. The overall aesthetic is graceful and
princess-like — this is the most elegant dinosaur character. CoComelon 3D quality,
ultra-vibrant blue saturation, masterpiece character sheet, 4K.
```

---

### GREEN GIZMO — COMPLETE DESIGN BRIEF

```
┌────────────────────────────────────────────────────────┐
│             GREEN GIZMO — CHARACTER SPECS              │
├──────────────────┬─────────────────────────────────────┤
│ Dinosaur Type    │ Triceratops (three-horned dinosaur)  │
│ Body Color       │ Forest Green #2E7D32 (main body)     │
│ Belly Color      │ Lime Green #A5D6A7 (soft belly)      │
│ Highlight        │ Bright Green #81C784 (top highlights)│
│ Eye Color        │ Bright Orange #FF6D00 (round eyes)   │
│ Frill Color      │ Rainbow-banded frill (neck frill)    │
│ Horn Feature     │ 3 horns each wrapped in orange and   │
│                  │ yellow flower garlands               │
│ Feet             │ Round bouncy feet — springs in soles │
│ Expression       │ Default: huge goofy toothy grin with │
│                  │ tongue sometimes out in joy          │
│ Personality      │ The class clown — bouncy, silly,     │
│                  │ enthusiastic, can't stop moving,     │
│                  │ loves to make others laugh            │
│ Movement         │ Literally bounces with every step    │
│                  │ Can't keep still — constant motion   │
└──────────────────┴─────────────────────────────────────┘
```

**GREEN GIZMO MASTER IMAGE PROMPT:**
```
Professional 3D animated character design reference of GREEN GIZMO, an original
Triceratops dinosaur character for TinyToons Universe. FULL BODY, FRONT-3/4 VIEW.
Forest green (#2E7D32) body; lime green (#A5D6A7) soft belly and face underside;
bright green highlights on back. Three prominent cartoon horns on the nose-brow
area — each horn wrapped completely in spiraling orange and yellow cartoon flower
garlands, making them festive rather than threatening. The neck frill behind the
head has a beautiful rainbow band pattern (7 colors in arcing stripes). Very large
round bright orange eyes with huge round pupils and double white star-shaped
catchlights. Enormous toothy grin showing many small round white teeth and a
cartoon tongue visible in the corner of the mouth. Round barrel-shaped body;
four compact legs with very round, slightly oversized feet suggesting springs.
Every part of this character suggests MOTION and BOUNCING — slightly dynamic
mid-bounce pose even in the reference sheet (feet slightly off ground). CoComelon
3D quality, ultra-vibrant green saturation, masterpiece character sheet, 4K.
```

---

## SETTING REFERENCE — THE RAINBOW JUNGLE

**MASTER SETTING IMAGE PROMPT (Generate background reference FIRST):**
```
Spectacular 3D animated background scene for "The Rainbow Dinosaur Parade" — a
magical Rainbow Jungle setting. A lush prehistoric-style jungle with oversized
cartoon plants: enormous round cartoon leaves in vivid green, pink, and yellow;
giant cartoon flowers in red, blue, orange, and purple (each flower as large as a
house); a wide, smooth colorful dirt road running left-to-right through the center
of the scene (the parade route) — the road is warm tan with colorful pebbles. In
the background: rolling cartoon hills in multiple shades of green graduating
lighter in the distance; a magnificent rainbow arcs across the sky from left to
right, every band vivid and thick. The sky is the most gorgeous cartoon blue with
perfectly round white clouds. Scattered throughout the jungle: cartoon butterflies
in vivid colors, small friendly cartoon birds, colorful mushrooms, and a cheerful
waterfall visible in the background dropping into a turquoise blue pool. The whole
scene glows with magical golden light. This is NOT a scary jungle — it is a magical
paradise designed for children. Ultra-vibrant, CoComelon 3D quality, horizontal
16:9 landscape composition, professional studio lighting, masterpiece, 4K.
```

---

## COMPLETE SONG SCRIPT — Copy for Voiceover

```
════════════════════════════════════════════════════════════
  AUDIO/VOICE SCRIPT — LONG VIDEO: THE RAINBOW DINOSAUR PARADE
  Primary Voice: ElevenLabs "Lily" (Tino, narrator) — Speed 0.95x, Pitch +5%
  Secondary Voice: ElevenLabs "Sarah" (Priya, Blue Bella lines) — Speed 0.92x
  Tertiary Voice: ElevenLabs "Daniel" (Arjun, Green Gizmo announcements) — Speed 1.0x
════════════════════════════════════════════════════════════

[INTRO — 0:00 to 0:08]
[BUILDING+GRAND+TINO]
🎵 Oh! Oh! Oh! [PAUSE:0.3]
[EXCITED+ANNOUNCES] HERE COME THE DINOSAURS! [PAUSE:0.5]
[GRAND+WARM] TinyToons Universe — [PAUSE:0.2]
it's the RAINBOW DINOSAUR PARADE! [SFX: trumpet fanfare] 🎵

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[VERSE 1 — RED REX — 0:08 to 0:40]
[ENTHUSIASTIC+STORYTELLING+TINO]
Here comes RED REX, [PAUSE:0.3] red as can be!
Stomping through the jungle [PAUSE:0.2] wild and free!
Red like apples, [PAUSE:0.2] red like the rose, [PAUSE:0.3]
That's the color RED — [EMPHASIS: RED] everybody knows! [PAUSE:0.5]

[BUILDING+TINO]
His big red tail goes WHOMP on the ground! [SFX: bass thud]
[PAUSE:0.3]
His big red feet go STOMP all around! [SFX: stomp stomp]
[PAUSE:0.3]
With his big red smile and his bright red eyes, [PAUSE:0.3]
Red Rex is heading for the RAINBOW SKIES! 🌈 [PAUSE:0.5]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[PRE-CHORUS 1 — 0:40 to 0:48]
[CALL-LEADER+TINO] ROAR like Red Rex! [PAUSE:0.2]
[RESPONSE+ALL KIDS] ROOAAAR! [SFX: funny cartoon roar]
[CALL-LEADER+TINO] STOMP like Red Rex! [PAUSE:0.2]
[RESPONSE+ALL KIDS] STOMP STOMP STOMP! [SFX: stomp stomp stomp]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[CHORUS — 0:48 to 1:12]
[FULL ENERGY+TINO LEAD+ALL VOICES JOIN]
Dinosaur parade! Dinosaur parade! [PAUSE:0.3]
All the colors of the RAINBOW on display! [PAUSE:0.3]
Dinosaur parade! Dinosaur parade! [PAUSE:0.3]
Come and MARCH with us TODAY! [PAUSE:0.3]
[GRAND+ALL TOGETHER] Hip hip — [PAUSE:0.2] HOORAY! 🎉 [SFX: cheer]
[PAUSE:0.5]
[REPEAT SOFTER] Dinosaur parade! Dinosaur parade!
All the colors of the RAINBOW here today!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[VERSE 2 — BLUE BELLA — 1:12 to 1:44]
[GENTLE+MELODIC+PRIYA VOICE]
Here comes BLUE BELLA, [PAUSE:0.3] gentle and tall!
She loves the ocean [PAUSE:0.2] and the waterfall!
Blue like the sky, [PAUSE:0.2] blue like the sea, [PAUSE:0.3]
Blue Bella sways [PAUSE:0.2] so gracefully! [PAUSE:0.5]

[BUILDING GENTLY+PRIYA]
Her long blue neck curves [PAUSE:0.2] up to the clouds, [PAUSE:0.3]
She waves to everyone [PAUSE:0.2] in the crowd! [PAUSE:0.3]
With her long blue tail and her big blue eyes, [PAUSE:0.3]
Blue Bella dances [PAUSE:0.2] under rainbow skies! 🌈 [PAUSE:0.5]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[PRE-CHORUS 2 — 1:44 to 1:52]
[CALL-LEADER+PRIYA] ROAR like Blue Bella! [PAUSE:0.2]
[RESPONSE — SOFT AND GENTLE] rooaaar... [SFX: gentle roar]
[CALL-LEADER+PRIYA] SWAY like Blue Bella! [PAUSE:0.2]
[RESPONSE] swayyy...swayyy... [everyone sways arms slowly]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[CHORUS REPEAT — 1:52 to 2:12]
[FULL ENERGY+ALL TOGETHER]
Dinosaur parade! Dinosaur parade!
All the colors of the RAINBOW on display!
Dinosaur parade! Dinosaur parade!
Come and march with us today!
Hip hip — HOORAY! 🎉

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[VERSE 3 — GREEN GIZMO — 2:12 to 2:40]
[BOUNCY+EXCITED+ARJUN VOICE+FAST ENERGY]
Here comes GREEN GIZMO [PAUSE:0.2] bouncing about!
He loves the forest [PAUSE:0.2] with a HOP and a SHOUT! [SFX: boing]
Green like the leaves, [PAUSE:0.2] green like the tree, [PAUSE:0.3]
Come and BOUNCE with Gizmo — [PAUSE:0.2] bounce with me! [PAUSE:0.5]

[FAST+FUN+ARJUN]
His three green horns [PAUSE:0.2] have FLOWERS on top! [SFX: boing boing]
He bounces and bounces [PAUSE:0.2] and just CAN'T STOP! [SFX: boing boing boing]
With his round green belly [PAUSE:0.2] and bright green smile, [PAUSE:0.3]
Green Gizmo BOUNCES for miles and miles! 🦕 [PAUSE:0.5]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[PRE-CHORUS 3 — 2:40 to 2:48]
[CALL-LEADER+ARJUN] ROAR like Green Gizmo! [PAUSE:0.2]
[RESPONSE — BOUNCY+FUNNY] ROOAAAR! [BOING!] [SFX: roar + spring boing]
[CALL-LEADER+ARJUN] BOUNCE like Green Gizmo! [PAUSE:0.2]
[RESPONSE] BOING! BOING! BOING! [everyone bounces]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[CHORUS 3 — 2:48 to 3:12]
[MAXIMUM ENERGY — ALL THREE DINOS + ALL FOUR KIDS TOGETHER]
Dinosaur parade! Dinosaur parade!
All the colors of the RAINBOW on display!
DINOSAUR PARADE! DINOSAUR PARADE!
Come and march with us TODAY!
Hip hip HIP — HOORAY! HOORAY! HOORAY! 🎉🎉🎉

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[COUNTING BRIDGE — 3:12 to 3:32]
[CLEAR+COUNTING+TINO — slow and deliberate for learning]
[CLEAR] ONE dinosaur! [PAUSE:0.5] ONE! [SFX: stomp — Red Rex]
[CLEAR] TWO dinosaurs! [PAUSE:0.5] TWO! [SFX: sway — Blue Bella joins]
[CLEAR] THREE dinosaurs! [PAUSE:0.5] THREE! [SFX: boing — Green Gizmo jumps in]
[BUILDING] One — [PAUSE:0.2] two — [PAUSE:0.2] THREE! [PAUSE:0.3]
[GRAND+ALL] ROOAAARRR! [SFX: all three dinosaurs roar together — epic sound!] 🦕🦕🦕

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[GRAND FINALE CHORUS — 3:32 to 3:52]
[MAXIMUM POWER+EVERYTHING TOGETHER]
DINOSAUR PARADE! DINOSAUR PARADE!
All the colors of the RAINBOW here TODAY!
[CALLING EACH COLOR — pause for kids to point]
RED! [PAUSE:0.4] BLUE! [PAUSE:0.4] GREEN! [PAUSE:0.4]
[GRAND+JOYFUL]
Hip hip hip — HOORAY! HIP HIP HOORAY! 🌈🦕🎉

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[OUTRO — 3:52 to 4:00]
[TINO+WARM+WAVING — slowing down pace]
[WARM] Bye bye Red Rex! 👋 [PAUSE:0.3]
[WARM] Bye bye Blue Bella! 👋 [PAUSE:0.3]
[WARM] Bye bye Green Gizmo! 👋 [PAUSE:0.5]
[SLOW+LOVING] TinyToons Universe! [PAUSE:0.2]
See you next time! 🌈 [SFX: end chime]

════════════════════════════════════════════════════════════
SOUND EFFECTS LIST — Download all from Freesound.org
[0:00] Trumpet fanfare — "kids fanfare cartoon"
[0:20] Bass thud — "cartoon stomp bass"
[0:24] Stomp stomp — "cartoon footstep heavy"
[0:40] Cartoon roar — "kids cartoon dinosaur roar"
[0:44] Stomp stomp stomp — "cartoon stomp triple"
[0:48] March beat — embedded in music track
[1:09] Victory cheer — "kids cheer hooray"
[2:20] Spring boing — "cartoon boing spring"
[2:24] Boing boing boing — triple spring effect
[2:41] Bouncy roar — "cartoon roar funny"
[3:27] EPIC TRIPLE ROAR — three roars layered together
[4:00] End chime — "magical children chime bells"
════════════════════════════════════════════════════════════
```

---

## MUSIC DIRECTION

**Suno AI Prompt (copy exactly):**
```
Upbeat epic children's dinosaur parade march song, 125 BPM, G major, exciting brass
fanfare melody, playful xylophone counter-melody, marching snare drum with cowbell,
tuba bass line for comedy weight, glockenspiel sparkles, children's choir singing the
main melody, grand orchestral swells at each chorus, builds in energy with each verse,
prehistoric adventure meets cheerful nursery pop, professionally mixed, 4 minute
loop with distinct verse and chorus sections, fade out at end
```

**BPM:** 125 BPM (march tempo — perfect for a parade theme)
**Key:** G Major (bright, triumphant, warm — ideal for kids)
**Volume Mix in CapCut:** Voiceover 100% — Background music 28%

---

## SCENE-BY-SCENE PRODUCTION: 35 CLIPS (30 MAIN + 5 BUFFER)

> **16:9 LANDSCAPE FORMAT:** All images are horizontal. In Google ImageFX use
> "landscape" or "wide" mode. Add "horizontal 16:9 wide landscape composition"
> to every prompt.

---

### 📍 CLIP 01 | 0:00–0:08 | "[INTRO] OH OH OH! Here come the dinosaurs!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape composition — spectacular 3D animated opening title
card for "The Rainbow Dinosaur Parade" kids song. A magnificent rainbow-colored
jungle clearing stretches across the wide frame. In the center foreground, all four
kid characters stand in a row: Tino Starlight (golden curly hair, blue overalls, star
badge), Priya Sundar (black pigtails, pink salwar, yellow dupatta), Arjun Veer
(short black hair, orange kurta), and baby Starla (yellow star onesie, seated between
Tino and Arjun). All four are looking off toward the right side of the frame with
HUGE SHOCKED DELIGHTED expressions — mouths open in amazement, eyes enormous. The
right side of the frame shows the very beginning of enormous red dinosaur feet — just
the feet visible, implying a giant creature approaching from off-frame. The ground
shakes — visible cracks radiate from each footprint. At the very top of the frame,
bold golden 3D bubble text: "THE RAINBOW DINOSAUR PARADE! 🌈🦕". Jungle background
is lush, vivid, and warm. Ultra-vibrant, CoComelon 3D quality, professional studio
lighting, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical/portrait composition, all four
characters looking at camera (they must look RIGHT), muted colors, missing any of
the four kid characters, fully visible dinosaur (only feet), distorted proportions,
out of frame
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the opening title card: The text "THE RAINBOW DINOSAUR PARADE!" at
the top performs a dramatic scale-in animation from center outward over 2 seconds
— growing from 0% to 100% size with a golden sparkle burst on completion. The four
kid characters react progressively: first Tino's jaw drops slowly over 1 second,
then Priya clasps her hands to her cheeks over the next 0.5 seconds, then Arjun
steps backward in exaggerated shock, and Starla's eyes slowly grow wider and wider
with each passing second. The enormous red feet on the right side STOMP — the right
foot rises slowly upward then descends with earth-shaking force, sending a ripple
shockwave across the ground toward the kids. The jungle plants sway from the impact.
Camera holds on the wide establishing shot. Duration 8 seconds.
```

---

### 📍 CLIP 02 | 0:08–0:16 | "Here comes RED REX, red as can be! Stomping through the jungle wild and free!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — dramatic reveal of RED REX, the red T-Rex character
from TinyToons Universe. RED REX is positioned center-right in the frame, with his
full body visible from head to tail. He is vivid fire-engine red (#FF1744) from
snout to tail tip. Round friendly face with enormous warm yellow cartoon eyes and a
huge toothy friendly grin. Crown of small red hibiscus flowers on his head. Golden
star-shaped scale pattern visible on his back. Very round chubby belly, stubby short
T-Rex arms, thick powerful legs. He is MID-STRIDE — left leg forward, body leaning
slightly with movement, tail held out behind for balance. Size: absolutely enormous
— taller than the jungle trees visible in the background. In the foreground-left,
Tino, Priya, Arjun, and Starla watch with absolute amazed delight — they are tiny
compared to Red Rex. The jungle around Red Rex shows his scale — his feet are at
the level of tree canopies. Ultra-vibrant, maximum red saturation, CoComelon 3D
quality, horizontal landscape, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary dinosaur, aggressive
expression, sharp fangs, adult, nsfw, ugly, deformed, extra limbs, bad anatomy,
watermark, portrait/vertical composition, small Red Rex (must be enormous compared
to children), muted red colors, brown or gray, missing flower crown, realistic
dinosaur scales, dark shadows making it scary, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the Red Rex full body reveal: Red Rex continues his stride — his right
leg lifts slowly forward over 3 seconds, foot rising with cartoon weight, then
descending with a STOMP that sends a ripple of light across the ground. The impact
of each stomp shakes the frame very subtly — just 2-3 pixels of camera shake for 0.3
seconds (like a real stomp reverb). His tail swings naturally behind him, counterweight
to his stride. The hibiscus flower crown on his head bounces with each step. His large
yellow eyes blink once — a slow friendly blink. The kid characters in the foreground
jump slightly with each stomp impact — cute reactive bounces. Red Rex's golden star
scales shimmer briefly. Camera tracks very slowly RIGHT to follow Red Rex. Duration
8 seconds.
```

---

### 📍 CLIP 03 | 0:16–0:24 | "Red like apples, red like the rose — That's the color RED!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — vibrant educational color reveal scene. Center of
the frame shows an enormous glowing 3D text "RED" in vivid red with golden outline,
surrounded by a spectacular arrangement of red-colored cartoon objects: a giant
shiny red apple on the left (cartoon style, with a bright shine spot), a beautiful
blooming red rose in the center with lush green leaves, a small red fire truck on
the right, a red kite flying at the top, and red strawberries at the bottom. All
objects are arranged in a pleasing wreath-like composition around the word "RED".
Red Rex is visible in the far background looking on with pride — like these are "his"
colors. The background behind the arrangement is a clean soft white with a gentle
red-pink glow radiating outward. Tino stands to the left side, pointing at each
red object with an excited explaining expression. Ultra-vibrant, maximum red
palette, CoComelon 3D quality, horizontal landscape, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, adult, nsfw, ugly, deformed, bad
anatomy, watermark, vertical composition, non-red dominant colors, muted colors,
scary elements, wrong object shapes (must all be simple cartoon), missing "RED" text,
out of frame, distorted
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the red color reveal scene: The "RED" text in the center pulses with
a warm glow that radiates outward. Each red object around it subtly animates: the
apple rotates 15 degrees left then right like a display model. The rose petals
breathe gently — the bloom slightly expanding and contracting. The fire truck drives
in a tiny oval path in its spot. The kite above sways on an invisible string. The
strawberries bounce gently in place. Tino's pointing finger moves from the apple
to the rose to the fire truck in a slow arc over 5 seconds — educational gesture.
When he points at each object, that object brightens briefly with a golden glow
rim. Red Rex in the background nods his enormous head slowly in pride. Duration
8 seconds. Educational, bright, engaging motion.
```

---

### 📍 CLIP 04 | 0:24–0:32 | "His big red tail goes WHOMP! His big red feet go STOMP!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — close-up low-angle action shot of Red Rex's lower
body in motion. The camera is positioned at ground level looking upward at Red Rex's
enormous red tail and feet mid-STOMP. His right foot is visible in the near center
— massive, red, with three round cartoon toes — having just landed, creating a
STOMP impact crater with cartoon earth radiating outward in lines. His tail sweeps
across the upper right of the frame — thick, red, round at the tip — caught in a
dramatic WHOMP swing. The impact radiates concentric cartoon "STOMP!" and "WHOMP!"
sound effect text in bright yellow and orange letters bursting from the impact
points. In the left background at normal eye level, the kid characters are visible
jumping in reaction — tiny compared to the foot. The jungle floor has large round
colorful stones and soft grass. Warm golden lighting from above. Ultra-vibrant,
CoComelon 3D quality, horizontal landscape, low-angle cinematic drama, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, violent, adult, nsfw, ugly,
deformed, bad anatomy, watermark, vertical composition, muted colors, the stomp
looking dangerous or harmful, dark scary lighting, out of frame, distorted
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the low-angle stomp scene: The foot that has just landed slowly
raises again over 3 seconds — the cartoon earth under it slowly returning to normal
shape as it lifts. Meanwhile the tail has completed its WHOMP and is now swinging
back the other direction slowly. The "STOMP!" text on the ground glows brightly for
1.5 seconds then slowly fades. The "WHOMP!" text near the tail does the same on a
0.5 second delay. The earth impact crater slowly closes. Falling pebbles and dirt
clods from the stomp impact fall back down following natural physics — each piece
at a slightly different speed. The kids in the background are visible recovering
from their reactive jump — feet landing back softly. Camera stays low-angle, static.
Duration 8 seconds. Physical impact, physics-based debris.
```

---

### 📍 CLIP 05 | 0:32–0:40 | "With his big red smile... Red Rex heading for the rainbow skies!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — beautiful character moment between Red Rex and the
four kid characters. Red Rex has stopped walking and looks down at the four tiny
children with an expression of pure gentle warmth and pride. His enormous face is
in the right portion of the frame, angled downward. His yellow eyes are soft and
kind. His huge friendly grin is warm, not scary. The four kids are in the left-
center portion of the frame, all looking up at him: Tino has both fists raised in
celebration, Priya has clasped hands at her heart in delight, Arjun has both thumbs
up, and Starla has both tiny arms raised upward as if asking to be picked up by the
giant dinosaur. Above Red Rex's head, the sky is a gorgeous gradient with a full
rainbow visible. The jungle around them is bright and lush. This is an emotionally
warm and beautiful moment — big and small connecting. Ultra-vibrant, warm golden
lighting, CoComelon 3D quality, horizontal landscape, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, Red Rex looking scary or
aggressive, kids looking frightened (they must be delighted), muted colors, cold
lighting, missing any of the four kid characters, out of frame
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the warm character moment between Red Rex and the kids: Red Rex's
enormous head slowly lowers a fraction (5%) toward the kids — a gentle bowing
gesture of friendliness. His tail wags behind him like an excited dog — swinging
left and right with happy energy over the full 8 seconds. Tino's raised fists pump
up and down twice. Priya's clasped hands bounce at her heart. Arjun's two thumbs
rotate in small circles. Starla's reaching tiny arms wave enthusiastically. Red Rex
blinks one slow friendly blink. The sky behind him slowly brightens in the rainbow
area — colors becoming more vivid. Flower crown on Red Rex's head sways gently.
The emotional warmth of this moment should feel like a Disney character connection.
Duration 8 seconds.
```

---

### 📍 CLIP 06 | 0:40–0:48 | "[PRE-CHORUS 1] ROAR like Red Rex! STOMP like Red Rex!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — dynamic action call-and-response pre-chorus scene.
CENTER FRAME: Red Rex has lowered his head to approximately the height of the kids
and is performing a ROAR facing the camera — mouth wide open, showing his round
friendly teeth, cartoon "ROARRR!" waves radiating from his open mouth in colorful
sound wave rings (red, orange, yellow). His expression is PLAYFUL, not scary — like
a parent pretending to be a monster in a game. LEFT FRAME: All four kids copy the
roar! Tino has his arms wide and mouth open in a tiny roar imitation; Priya has
her fingers spread like claws; Arjun has his fists raised in a superhero roar; Starla
has her mouth open in a tiny toothless baby roar attempt — the most adorably
ineffective roar face imaginable. The ground shows both Red Rex's stomp impact and
the kids' tiny stomp attempts beside it (the kids' stomps barely leave a mark —
comedy contrast). Ultra-vibrant, CoComelon 3D quality, horizontal landscape, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary roar (must be playful), adult,
nsfw, ugly, deformed, extra limbs, bad anatomy, watermark, vertical composition,
frightened kids (they must be copying enthusiastically), dark sound waves (must be
colorful), out of frame, cropped, muted colors
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the roar call-and-response scene: Red Rex's roar mouth is open —
the colorful sound waves pulse outward from his open mouth rhythmically, each wave
expanding in a concentric ring and fading. Each wave takes 1.5 seconds to expand
and fade, so 5-6 waves pulse during the 8 seconds. The kids on the left perform
their roar imitation in sequence: Tino starts first (arms out, mouth wide), Priya
follows 0.5 seconds later (claw hands), Arjun follows (fists raised roar), Starla
last — opens mouth wide and produces... almost nothing. Her tiny squeak is implied
by one very small sound wave ring emerging from her. Everyone laughs (implied by
expressions). Red Rex's eyes squint with joy at the kids' attempt. Duration 8 sec.
```

---

### 📍 CLIP 07 | 0:48–0:56 | "[CHORUS] Dinosaur parade! Dinosaur parade! All the colors of the rainbow!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — spectacular PARADE BEGINS scene. The parade route
road stretches from left to right across the bottom third of the frame. Red Rex
walks confidently at the FRONT of the parade in the center-right, facing the right.
Just behind him and to his left: Tino marches enthusiastically — knees high, arms
swinging. Priya marches beside Tino, one hand raised. Arjun marches on the other
side. Starla is being carried aloft on Arjun's shoulders, arms raised in pure joy.
The jungle on both sides of the parade route is filled with watching cartoon
animals — colorful birds on branches cheering, cartoon butterflies flying alongside,
small friendly jungle creatures waving. Above the parade, a spectacular rainbow
fills the sky. Confetti and colorful flower petals rain down from the jungle canopy.
This is a JOYFUL CELEBRATION. Bold golden subtitle at the top: "DINOSAUR PARADE! 🌈".
Ultra-vibrant, CoComelon 3D quality, horizontal landscape, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, everyone standing still
(they must be marching), muted colors, empty background, missing any characters,
Starla on the ground (she must be on Arjun's shoulders), out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the parade scene: The entire group moves from left to right in a
continuous march. Red Rex's enormous feet lift and plant in a marching rhythm — each
footstep about 1.5 seconds apart. His tail sweeps side to side with each step. The
four kid characters march in sync with Red Rex's rhythm: knees lifting, arms
swinging in natural walking opposition. Starla on Arjun's shoulders bounces gently
with each step, her single curl bobbing. Confetti and flower petals fall continuously
from above at different speeds. The watching cartoon animals along the route react:
birds flap wings, butterflies flit, small creatures wave. Camera tracks left-to-right
slowly following the parade. Rainbow in sky brightens with a pulse. Duration 8 sec.
```

---

### 📍 CLIP 08 | 0:56–1:04 | "Dinosaur parade! Come and march with us today!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — direct engagement parade scene. The parade is
marching DIRECTLY TOWARD THE CAMERA from a distance, so all characters face forward.
Red Rex is centered and enormous, directly facing the viewer, still walking forward.
His expression invites: eyes warm, grin huge, head slightly lowered toward camera.
The four kids march in front of him (between Rex and the camera), each facing
forward: Tino with arms spread wide in an inviting "come join us!" gesture, Priya
waving at camera, Arjun doing a little march dance step, Starla (back on the ground
now, seated in a small cart pulled by a cartoon turtle) waving both chubby fists.
The parade road recedes to a vanishing point in the background. Bold 3D text
"COME MARCH WITH US! 🎉" floats above the characters in golden bubble letters. The
sky behind them is full rainbow glory. Ultra-vibrant, CoComelon 3D quality,
horizontal landscape, direct camera engagement, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, characters facing away
from camera, muted colors, static/non-marching poses, missing characters, out of
frame, Starla not in the scene, dark background, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the parade directly facing camera: The whole group continues marching
toward the camera — gradually getting slightly larger each second as they approach
(very slow zoom-in implied by character size growth). Red Rex's enormous face looms
larger over 8 seconds. Tino's inviting arms sweep wider then back, repeating the
welcoming gesture twice. Priya's wave is a simple 3-count wave repeating. Arjun
does a little shuffle step — both feet tapping the ground alternately. The cartoon
turtle pulling Starla's cart plods forward steadily, Starla bouncing in the cart.
The "COME MARCH WITH US!" text pulses in rhythm with the march beat. Colorful
flowers on the parade route sides bob as the group passes. Duration 8 seconds.
```

---

### 📍 CLIP 09 | 1:04–1:12 | "Hip Hip — HOORAY! Hip Hip HOORAY!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — GRAND CELEBRATION MOMENT. The entire group has
STOPPED and is celebrating in a spectacular wide tableau. Red Rex is at the center-
back, enormous, with both his tiny T-Rex arms raised as high as they can go (which
is adorably limited — they only reach about chest height — comedy moment). His face
shows maximum joy — biggest grin, eyes squinting with happiness. In front of him,
all four kids celebrate in different ways: Tino jumps with both arms up, Priya spins
with arms out (dupatta flying), Arjun has both fists punched into the air, Starla
claps with all her might. ABOVE EVERYTHING: an explosion of colorful confetti,
golden stars, and rainbow streamers bursts outward from the center of the frame as
if from a party cannon. The sky shows the most spectacular rainbow composition of
the whole video. Bold golden text: "HOORAY! 🎉🌈" in massive 3D letters at the top.
Ultra-vibrant, MAXIMUM celebration energy, CoComelon 3D quality, horizontal, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, quiet/subdued (must be explosive
celebration), adult, nsfw, ugly, deformed, extra limbs, bad anatomy, watermark,
vertical composition, static poses, muted confetti, missing any characters, out of
frame, Red Rex's arms raised higher than realistic T-Rex anatomy allows, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the celebration scene: The confetti burst is in progress — particles
are already in the air mid-explosion. They continue following physics: initial
burst velocity slows, particles reach peak then fall in natural arcs. Each confetti
piece tumbles and rotates. Golden stars pulse with brightness then fade. Red Rex's
stubby arms lower from their raised position slowly — comedy in the limitation
of his arm reach. Tino lands from his jump, knees bending on contact. Priya's spin
completes, her dupatta settling around her. Arjun's raised fists pump twice more.
Starla claps 4 times rapidly then throws both hands up. A rainbow arc in the sky
does one full color-sweep pulse (red brightens, then orange, yellow, green, blue,
violet in sequence). Duration 8 seconds. Pure joyful energy.
```

---

### 📍 CLIP 10 | 1:12–1:20 | "Here comes BLUE BELLA, gentle and tall! She loves the ocean!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — magical entrance of BLUE BELLA, the blue
Brachiosaurus. She enters from the LEFT side of the frame, her long elegant neck
sweeping gracefully into view first, followed by her body. She is positioned toward
the left-center, and because of her enormous height her head and neck fill the
left portion of the sky area while her body occupies the ground level. BLUE BELLA:
ocean blue (#1565C0) body with sky-blue (#90CAF9) belly; string of white jasmine
flower beads at her neck base; warm amber oval eyes with luxurious lashes; serene
graceful closed smile. Around her, the jungle becomes more OCEAN-THEMED: a beautiful
blue waterfall cascades in the background, aquamarine streams flow at ground level,
water lilies float, cartoon fish jump playfully. The four kids watch from the right
side of frame with NEW amazement — different from Red Rex's power, Blue Bella
inspires awe and beauty. Golden soft lighting. Ultra-vibrant, CoComelon 3D quality,
horizontal landscape, graceful cinematic composition, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, non-blue body (must be
blue), missing jasmine necklace, wrong eye shape (must be large oval with long lashes),
muted colors, Bella looking aggressive, no water elements, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from Blue Bella's graceful entrance: Her long neck continues its elegant
sweep from left into the frame — the neck curving in a beautiful S shape as her
head comes to rest in the sky portion of the left frame. The motion is slow, flowing,
and graceful — like a dancer. Her amber eyes are half-closed in serene contentment,
then slowly open fully to look at the kids with warm kindness. The jasmine flower
bead necklace sways gently with her neck motion. The butterfly bow at her tail
tip flutters as if alive. The waterfall in the background flows continuously, water
cascading down in smooth sheets. The lily pads on the water surface drift slowly.
The kids' expressions shift to wonder: Priya's hands clasp at her heart, Tino steps
forward in amazement, Arjun stares upward with his head tilted back. Duration 8 sec.
```

---

### 📍 CLIP 11 | 1:20–1:28 | "Blue like the sky, blue like the sea — Blue Bella sways so gracefully!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — Blue Bella in full graceful motion, performing a
gentle swaying dance. Her long neck curves and sways in a beautiful arc from left
to right. Her huge amber eyes are joyfully closed. The entire scene around her is
BLUE-THEMED: deep blue sky above, a glistening blue ocean visible through gaps in
the jungle on the left, a beautiful cascade waterfall on the right. In the center
foreground, the four kids are swaying LEFT AND RIGHT in imitation of Blue Bella —
each swaying at slightly different timings creating a beautiful wave effect in the
group. Priya sways with classical Indian dance grace; Tino sways with arms out;
Arjun sways with slightly exaggerated comedy timing; Starla's whole body topples
left then right — baby sway physics. Blue Bella's butterfly tail bow is also swaying.
The entire scene feels like it is BREATHING with gentle rhythm. Ultra-vibrant,
CoComelon 3D quality, horizontal landscape, graceful flowing composition, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, angular/stiff movements (must
be graceful and flowing), adult, nsfw, ugly, deformed, bad anatomy, watermark,
vertical composition, Red Rex in this scene (wrong dino), non-blue environment,
kids standing still (they must be swaying), muted colors, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from Blue Bella's graceful sway scene: Blue Bella's long neck performs one
full sway cycle over 8 seconds — arcing slowly from its initial right-of-center
position to far left over 4 seconds, then back to center by second 8. The motion is
absolutely smooth and flowing, like seaweed in gentle water current. Her closed eyes
contribute to the sense of blissful contentment. The kids sway in rough sync with
her: starting sway 0.5 seconds after Bella's motion direction changes. Each kid's
sway has its own personality (see prompt above). The ocean visible through the trees
has gentle waves lapping. The waterfall flows continuously. Bella's jasmine necklace
has a gentle liquid motion as it sways. Duration 8 seconds. Smooth, meditative, beautiful.
```

---

### 📍 CLIP 12 | 1:28–1:36 | "Her long blue neck curves up to the clouds! She waves to everyone!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — Blue Bella's neck reaching INTO THE CLOUDS. This
is a spectacular scale shot: her body occupies the left-lower portion of the frame
at ground level, and her extraordinarily long neck arcs upward, disappearing into
a fluffy white cloud in the upper-right portion of the sky. Her head emerges ABOVE
the cloud at the very top-right of the frame — she's ABOVE THE CLOUDS. She looks
down from this incredible height with a gentle wave — one front leg raised in a
graceful waving gesture. Below, at ground level, the four kids are tiny specks
looking up. Tino and Priya are waving back enthusiastically upward. The scale
contrast is breathtaking but magical and safe-feeling — not scary. The clouds
around her neck are soft and white. The sky is a gorgeous deep blue. Birds fly past
her at the cloud level. Ultra-vibrant, CoComelon 3D quality, horizontal landscape,
breathtaking scale composition, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary heights, adult, nsfw, ugly,
deformed, bad anatomy, watermark, vertical composition, Bella's head NOT above
clouds, muted colors, kids not visible (must be tiny at bottom), wrong sky color,
the scene feeling scary (must feel magical), out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the above-clouds scale scene: Blue Bella's waving gesture is in
motion — her front leg raises in a slow graceful arc, holds for 2 seconds, then
lowers. Her head above the cloud rotates very slowly to look left then right, like
she's admiring the view. Clouds gently drift: the cloud around her neck slowly
shifts rightward about 5% of the frame. Three cartoon birds fly past her head from
left to right in a gentle V formation. At ground level, the tiny kid figures wave
upward — their movements small but visible. Priya's yellow dupatta catches a breeze
from the height. Tino jumps up on his toes to wave higher (adorably pointless given
the scale). The deep blue sky pulses with one gentle brightness change. Duration 8 sec.
```

---

### 📍 CLIP 13 | 1:36–1:44 | "Blue Bella dances under rainbow skies! — Arjun and Starla react!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — joyful Blue Bella scene focusing on Arjun and
Starla's reactions. Blue Bella now at normal eye-level angle, swaying and dancing
gently on the left side of the frame. RIGHT SIDE: Arjun stands with mouth hanging
wide open, one hand on his head in disbelief amazement — his typically confident
expression completely overtaken by awe. Starla is RIGHT IN THE FOREGROUND in
close-up — her enormous baby eyes fill with sparkling wonder, both tiny hands
pressed to her cheeks in the baby amazed-face gesture. A single round blue teardrop
of JOY (not sadness) forms at the corner of Starla's eye — it's too beautiful.
Between the two, Priya stands with both hands clasped at her heart, eyes shining
with a radiant expression of beauty-appreciation. Blue Bella's tail with the
butterfly bow is visible at the extreme left edge, swaying. The sky shows a gorgeous
deep blue with rainbow. Ultra-vibrant, CoComelon 3D quality, horizontal, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, sad reactions (must be amazed/
moved by beauty), adult, nsfw, ugly, deformed, bad anatomy, watermark, vertical
composition, wrong dino (must be Blue Bella, not Red Rex), distorted proportions,
Starla's tear looking like crying-sad (must be beautiful joy tear), muted colors,
out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the reaction close-up scene: Arjun's open-mouth awe expression slowly
transforms over 4 seconds from pure shock to a warm, proud smile — like he realizes
Blue Bella is amazing and that's actually great. His hand on his head slowly lowers.
Starla's joy teardrop in the corner of her eye grows slightly larger then rolls
slowly down her chubby cheek following gravity — a perfect sphere rolling at medium
speed, catching the light. When it reaches her cheek, it sparkles like a little
gem. Priya's clasped hands at her heart slowly squeeze tighter with emotion.
Blue Bella's swaying on the left continues — her butterfly bow on the tail slowly
opens and closes its wings. The rainbow in the sky brightens one pulse. Duration 8 sec.
```

---

### 📍 CLIP 14 | 1:44–1:52 | "[PRE-CHORUS 2] ROAR like Blue Bella! SWAY like Blue Bella!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — the GENTLE ROAR pre-chorus. Blue Bella has lowered
her head to character level (her neck curving down gracefully) and opens her mouth
in a GENTLE, MELODIOUS roar — not fierce, but like singing. The sound waves from
her mouth are SOFT BLUE AND TURQUOISE spiraling shapes — more like music waves than
power waves. Her eyes are soft and warm while roaring. In front of her, all four
kids imitate a gentle sway: everyone sways left and right — arms extended softly
to the sides, eyes half-closed in peaceful imitation. Priya's imitation is the most
graceful (Indian dance influence). Tino's is enthusiastic but a bit too wide.
Arjun's is deliberately slow and careful (trying to be graceful). Starla sways so
much she nearly topples left but catches herself. Above them all, soft blue musical
notes float upward. Ultra-vibrant, CoComelon 3D quality, horizontal landscape, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, aggressive roar (must be gentle/
melodious), adult, nsfw, ugly, deformed, bad anatomy, watermark, vertical
composition, fierce scary Blue Bella expression, red/orange sound waves (must be
soft blue), kids looking scared, muted colors, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the gentle roar scene: Blue Bella's melodious roar sends out slow-
expanding soft blue sound wave spirals. Each spiral expands outward over 3 seconds
then fades gently. Two complete spiral patterns pulse during the 8 seconds. The
musical note shapes float slowly upward from her mouth — each note spinning slowly
on its own axis as it rises. The kids' sway is in rhythm — arms moving in slow
synchronized arcs left then right then left, each taking about 2.5 seconds per
full cycle so they complete about 3 cycles in 8 seconds. The swaying has a wave
quality — Tino starts, then Priya, then Arjun, then Starla, with 0.3 second delays.
Starla's overcorrection wobble is very slow and funny. Duration 8 seconds. Gentle, musical.
```

---

### 📍 CLIP 15 | 1:52–2:00 | "[CHORUS REPEAT] Dinosaur parade! — Now 2 dinos march!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — the SECOND DINOSAUR JOINS THE PARADE. The parade
road is now fuller and more spectacular. RED REX leads at the front-right, marching
proudly with his characteristic STOMP rhythm. Just behind him and to the left, BLUE
BELLA sways elegantly as she walks — her long neck arcing gracefully above the crowd.
Between and in front of them, the four kid characters march: Tino and Arjun marching
powerfully (copying Red Rex), Priya swaying gracefully (copying Blue Bella), Starla
in her little turtle-cart waving at everything she sees. The parade route has grown
more festive: colorful banners now hang between the jungle trees, cartoon confetti
floats everywhere, jungle animals line the route and cheer enthusiastically — a
rainbow parrot waves a tiny flag, a cartoon elephant blows its trunk in a trumpet
call, tiny monkeys throw flowers. The rainbow sky is spectacular. Ultra-vibrant,
CoComelon 3D quality, horizontal landscape, parade spectacle, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, only one dino (must show
BOTH), muted colors, empty route (must be festive), missing kid characters, out of
frame, cropped, spectator animals missing
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the two-dino parade scene: The whole parade moves steadily right to
left in this frame (different direction adds visual variety). Red Rex leads with his
STOMP march — each step has the same subtle camera shake as before. Blue Bella's
walk is different — smooth, gliding steps, her neck swaying rhythmically above.
Their contrasting walking styles side-by-side are visually delightful. The banner
decorations between the trees sway with the movement of the parade past them. The
rainbow parrot waves its flag in small precise waves. The elephant's trunk raises
in a trumpet pose. Flower confetti falls from the monkey spectators above. Tino and
Arjun pump their arms marching. Priya swings her arms in a graceful arc. Camera
tracks the parade from right to left. Duration 8 seconds.
```

---

### 📍 CLIP 16 | 2:00–2:08 | "All the colors of the rainbow on display! — Wide parade aerial!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — SPECTACULAR AERIAL VIEW of the full parade from
above. This is the widest, most panoramic shot of the video. The view is from high
above looking down at a gentle angle. The parade route winds through the Rainbow
Jungle like a colorful river of characters. From this height: Red Rex is a vivid
red shape at the front-center; Blue Bella's long blue neck and body is distinctly
graceful and tall behind him; the four tiny kid characters are colorful specks
between the dinosaurs. The jungle on both sides is an explosion of vivid tropical
color — seen from above, the canopy is a gorgeous mosaic of green, with huge
flowers in red, yellow, blue, and purple. The rainbow stretches across the sky in
the upper portion of the frame. The parade route has footprints from Red Rex's
enormous feet left in the colorful ground behind them — a visual trail. This whole
image has a toybox quality — bright, safe, joyful. Ultra-vibrant, CoComelon 3D
quality, horizontal landscape, aerial perspective, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
bad anatomy, watermark, vertical composition, ground-level shot (must be aerial),
muted jungle colors, missing parade characters, the scene looking dangerous, out
of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the aerial parade view: The camera very slowly zooms outward (pulls
back) over 8 seconds — revealing progressively more of the jungle landscape. The
parade characters move continuously along the route — at this scale their motion
is slower-looking but still clearly progressing. Red Rex's red body moves steadily
forward. Blue Bella's neck sways in a gentle rhythm visible even from above. The
jungle canopy gently ripples with a soft breeze — a wave passing through the leaves
from right to left. New butterflies and birds appear at frame edges as the camera
pulls back. The rainbow in the upper sky brightens slightly. The footprint trail
behind Red Rex grows longer as he advances. Duration 8 seconds. Majestic scale.
```

---

### 📍 CLIP 17 | 2:08–2:16 | "Here comes GREEN GIZMO bouncing about! — BOUNCY ENTRANCE!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — EXPLOSIVE COMEDIC ENTRANCE of GREEN GIZMO the
Triceratops. He BOUNCES INTO FRAME from the right side — caught at the exact moment
of landing from a HUGE bounce, creating a comedy impact crater around all four feet.
His body is round and vibrant forest green (#2E7D32) with lime belly; three horns
wrapped in orange-yellow flower garlands; rainbow-banded neck frill extended out
wide; enormous round orange eyes wide open; huge goofy toothy grin with cartoon
tongue visible at corner; four round feet currently at the lowest point of a bounce.
Spring coils are briefly visible in comedy cartoon form at his feet — BOING! The
four kids have all been knocked backward by the bounce impact — they are in various
comedy tumbling poses: Tino windmilling arms backward, Priya sitting down with a
surprised expression, Arjun stumbling, Starla's cart spinning. Green Gizmo looks
delighted with himself. Bold cartoon "BOING!" text pops from the impact point.
Ultra-vibrant, CoComelon 3D quality, horizontal landscape, comedy energy, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, Green Gizmo on the ground
(must be in a bounce landing), kids in pain (must be comedically surprised, not hurt),
missing flower garlands on horns, missing BOING! text, muted colors, non-green dino,
realistic triceratops proportions (must be very round and cartoon), out of frame
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from Green Gizmo's bounce-landing scene: Gizmo's bounce landing completes:
his four feet contact the ground creating a circular shockwave, the cartoon "BOING!"
text glows and fades over 2 seconds. He immediately bounces again — launching
upward with spring-coil legs, rising to half his height above the ground over 3
seconds at peak, then descending back down for a smaller second landing at second 7.
His flower garland horns bounce and flap with each motion. His round belly wobbles
with a cartoon jiggle on landing. The frill behind his head fans outward on each
landing and compresses on each rise. The kids' cartoon tumble reactions animate:
Tino's windmilling slows and he regains balance, laughing. Priya stands back up.
Arjun does a quick recovery cool-spin to pretend he meant to fall. Starla in her
cart spins and comes to a dizzy stop — stars above her head. Duration 8 seconds.
```

---

### 📍 CLIP 18 | 2:16–2:24 | "He loves the forest with a HOP and a SHOUT! Green like the leaves!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — Green Gizmo in his natural habitat: the FOREST.
He is surrounded by lush oversized cartoon trees and plants that are ALL SHADES OF
GREEN. He is MID-HOP — all four feet off the ground, body at peak of a medium hop.
His expression is maximum silliness: eyes crossed slightly from the hop joy, tongue
fully out, flower garlands on horns flying outward from motion, rainbow frill
extended. Around him, the forest reacts to his constant bouncing: frogs leap from
lily pads, small cartoon rabbits hop in imitation, birds fly up startled then
descend amused, leaves shower down from trees with each bounce impact. In the
foreground, Tino and Arjun are attempting to COPY Gizmo's bouncing — their jumps
are smaller and human, but they're giving it full effort. Priya watches with one
hand over her mouth giggling. The whole scene has a bright green light cast from
the forest. Ultra-vibrant, forest green, CoComelon 3D quality, horizontal landscape, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, adult, nsfw, ugly, deformed, bad
anatomy, watermark, vertical composition, Gizmo on the ground (must be mid-hop),
missing flower garlands, wrong dino type, muted green colors, kids standing still
(Tino and Arjun must be bouncing), non-forest setting, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from Green Gizmo mid-hop in the forest: Gizmo descends from the hop peak,
all four feet landing with a BOING and immediate re-launch upward — he performs 2
complete hop cycles in the 8 seconds (each cycle: launch, peak at 3 sec, land at
6 sec, re-launch). Leaves shower down from the trees with each landing impact.
The frogs hop away on the lily pads — each frog leaping in sequence. Small rabbits
attempt to copy Gizmo's bouncing with tiny hoppy jumps — very cute. Tino's copy-
bounce: he jumps with both feet, lands on both feet, immediately tries again — good
effort. Arjun's: more athletic, both feet, higher, he's actually getting close.
Priya's giggle is expressed through her shoulders shaking gently. Green Gizmo's
tongue flops in and out as he bounces. Duration 8 seconds. Maximum bouncy energy.
```

---

### 📍 CLIP 19 | 2:24–2:32 | "Green like the leaves, green like the tree — Bounce with Gizmo!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — GREEN COLOR EDUCATION SCENE featuring Green Gizmo.
Similar to the Red Rex color scene but GREEN THEMED. Center of frame shows enormous
3D bubble text "GREEN" in vivid forest green with lime outline, surrounded by a
beautiful arrangement of green cartoon objects: a giant cartoon maple leaf (bright
spring green), a round cartoon frog on a lily pad (kelly green), an enormous cartoon
tree (multiple shades of green), a green caterpillar on a branch, and bright green
grass growing at the bottom. All objects arranged in a pleasing composition around
the "GREEN" text. Green Gizmo is on the right side, seated for once (a rare moment
of stillness!), looking proudly at his color display with a huge grin. His flower
garlands sway gently. To the left, all four kids point at the green objects — Tino
pointing at the leaf, Priya at the frog, Arjun at the tree, Starla reaching toward
the caterpillar. Ultra-vibrant, maximum green palette, CoComelon 3D quality, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, adult, nsfw, ugly, deformed, bad
anatomy, watermark, vertical composition, non-green dominant colors, muted colors,
wrong dino (must be Green Gizmo), missing "GREEN" text, Gizmo bouncing (rare still
moment — he can be seated), out of frame, distorted
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the green color education scene: "GREEN" text pulses with a nature-
inspired glow — like sunlight through leaves. Each green object animates gently:
the maple leaf rotates slowly like a falling leaf in autumn, spinning lazily. The
frog on the lily pad blinks twice with large cartoon blinks. The tree's leaves
rustle — a wave of movement through the canopy from left to right. The caterpillar
takes one tiny step sideways. Green Gizmo seated: he can't help it — his bottom
bounces once gently against the ground, involuntary. His flower garland sways with
it. Each kid points at their object in sequence over 5 seconds: Tino to Priya to
Arjun to Starla. Each object brightens when pointed at, a golden rim light effect.
Duration 8 seconds. Educational, vibrant, gentle.
```

---

### 📍 CLIP 20 | 2:32–2:40 | "His three green horns have flowers on top! He bounces for miles!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — close-up COMEDY PORTRAIT of Green Gizmo's face
and shoulders, filling most of the frame. His face is enormous in the frame — round,
vivid green, maximum goofy expression: cross-eyes focusing on his own nose, enormous
toothy grin, tongue out to the side. His three horns with their flower garlands
dominate the upper portion of the frame — the garlands are vibrant and beautiful
against the green horns. His rainbow frill fans behind his head creating a gorgeous
color-burst background to the portrait. His round orange eyes (now uncrossed and
looking at camera) sparkle with comedy joy. Behind him and out of focus (bokeh),
the four kid characters are visible — all four are doubled over in giggles, hands
on knees or holding their sides, Arjun pointing at Gizmo in delighted amazement.
This is the COMEDY PEAK moment — even the dinosaur knows he's funny. Ultra-vibrant,
CoComelon 3D quality, horizontal landscape, portrait comedy, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, adult, nsfw, ugly, deformed, bad
anatomy, watermark, vertical composition, Gizmo looking sad or upset, missing flower
garlands on horns, wrong dinosaur type, muted colors, full-body shot (this is a
close-up portrait), kids not laughing, out of frame
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from Green Gizmo's comedy portrait close-up: His cross-eyed expression
slowly uncrosses over 2 seconds, eyes refocusing on camera — the uncrossing itself
is funny. He winks one eye (the right), a very slow deliberate wink over 1 second.
Then his tongue slowly retracts back into his mouth. He shakes his head slowly left
and right — this shakes the flower garlands on his horns, which flap and bounce
dramatically. His frill fans out to maximum width on the head-shake then settles
back. In the background, the laughing kids animate: Tino's shoulders shake with
laughter, Arjun points with increasing enthusiasm, Priya wipes a joy tear, Starla
falls backward onto her back from laughing too hard (soft landing, legs in the air).
Gizmo's expression shifts to warm pride at making everyone laugh. Duration 8 seconds.
```

---

### 📍 CLIP 21 | 2:40–2:48 | "[PRE-CHORUS 3] ALL THREE DINOSAURS ROAR TOGETHER — EPIC!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — THE MOST SPECTACULAR ROAR SCENE. All THREE
dinosaurs are in frame together for the first time simultaneously: RED REX on the
left, enormous and vivid red, head angled toward camera in a big playful roar;
BLUE BELLA in the center, head lowered gracefully from above, her gentle blue roar
more like a melodious call; GREEN GIZMO on the right, bouncing mid-roar, his roar
the funniest — mid-bounce making his roar go "boing" in pitch. ALL THREE mouths are
open simultaneously. The combined roar sound waves from all three create a SPECTACULAR
multi-color wave explosion in the center of the frame: red waves from Rex, blue
waves from Bella, green waves from Gizmo — all three colliding in the center and
creating a beautiful rainbow pattern where they meet. The four kid characters are in
the very foreground, tiny, all three simultaneously roaring in their best dinosaur
imitations. This is the VISUAL PEAK pre-finale moment. Ultra-vibrant, CoComelon 3D
quality, horizontal landscape, epic three-dino ensemble, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary (must be playful/funny),
adult, nsfw, ugly, deformed, extra limbs, bad anatomy, watermark, vertical
composition, not all three dinos visible simultaneously (all three required), muted
colors, monochrome sound waves (must be multi-color), kids looking scared, out of
frame, missing any of the three dinosaurs
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the epic triple roar scene: All three dinosaur roar sound-waves are
in motion simultaneously. Each set of waves expands at a slightly different speed
(Red Rex fastest, Blue Bella slowest, Green Gizmo medium-but-bouncy). Where the
waves meet in the center, they create interference patterns of rainbow color that
bloom and pulse beautifully. Each wave expands to the frame edges and fades over
3 seconds, then a new wave set begins. The four kid characters in the foreground
add their roars in sequence: Tino starts first with arms spread wide, then Priya
with hands in claw position, then Arjun with maximum volume effort, finally Starla
— her tiny mouth opens and produces a single small wobbling ring. Everyone freezes
for 0.5 seconds at peak, then breaks into laughter. Duration 8 seconds. EPIC MOMENT.
```

---

### 📍 CLIP 22 | 2:48–2:56 | "[CHORUS 3 — ALL DINOS MARCH] DINOSAUR PARADE with all three!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — MAXIMUM PARADE SPECTACULAR. All three dinosaurs
march TOGETHER in a magnificent line, filling the frame: RED REX stomping on the
left with his powerful march; BLUE BELLA swaying gracefully in the center, her long
neck arcing above; GREEN GIZMO bouncing on the right with his signature boing-steps.
Their contrasting walking styles are delightfully funny and beautiful side by side.
The four kid characters march in front of all three, tiny in comparison: Tino, Priya,
Arjun, Starla in her turtle cart. The parade route is now decorated to maximum
festivity: rainbow banners, thousands of flowers, confetti streaming from everywhere.
Jungle animals along the route include: a giraffe waving its neck, colorful parrots
in formation, cartoon elephants, a crowd of small jungle creatures. The sky shows
the most spectacular rainbow, and multiple fireworks of color have been added at
the top — celebration fireworks in gold, red, blue, green, exploding beautifully.
Ultra-vibrant, CoComelon 3D quality, horizontal landscape, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, not all three dinos
present (all three required), two dinos moving same way (each has distinct style),
muted colors, empty route, missing kid characters, out of frame, fireworks looking
dangerous (must be colorful and safe cartoon style), cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the three-dino maximum parade scene: Each dinosaur animates in its
distinct style simultaneously — the contrast between the three is the core beauty
of this shot. Red Rex STOMPS: each footstep sends the ground ripple. Blue Bella
SWAYS: neck arcing, steps gliding, butterfly bow fluttering. Green Gizmo BOUNCES:
spring-steps, flower garlands flying, frill fanning. The kid characters march in
between the legs of the dinosaurs — Tino looking up in awe at Rex, Priya glancing
gracefully at Bella, Arjun trying to copy Gizmo's bounce-step, Starla spinning in
her cart. Cartoon fireworks in the upper sky burst in colorful explosions —
expanding from a point to a full star pattern over 2 seconds each, then fading.
Three separate fireworks burst during the 8 seconds. Camera pulls slowly backward
to take in the full spectacular scene. Duration 8 seconds.
```

---

### 📍 CLIP 23 | 2:56–3:04 | "All the colors of the rainbow here today! — Aerial parade shot"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — CINEMATIC AERIAL TRACKING SHOT of all three
dinosaurs plus kids mid-parade. From a high-angle perspective above and slightly
ahead of the parade, looking back toward the marching group. This gives a grand
"movie trailer" quality shot. In the foreground of the aerial view: Green Gizmo
seen from above and ahead (his flowers on his horns visible from this angle —
charming). Mid-frame: Blue Bella's back and long neck curving upward. Background-
frame: Red Rex at the rear, enormous and vivid red. Between them: tiny kid
characters. The parade route stretches behind them showing their entire journey —
Red Rex's enormous footprints left in the ground behind him form a trail like
prehistoric dinosaur fossils in a fun way. The Rainbow Jungle on both sides of the
route stretches to the horizon. The sky has the most gorgeous sunset-rainbow
combination: warm orange and pink alongside the rainbow arc. Ultra-vibrant,
CoComelon 3D quality, cinematic aerial perspective, horizontal landscape, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
bad anatomy, watermark, vertical composition, ground-level shot (must be aerial),
all three dinos must be visible, muted colors, empty background, the footprint
trail missing, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the cinematic aerial tracking shot: The camera slowly moves forward
(tracking the parade direction) while maintaining the aerial angle — so the parade
characters grow very gradually as the camera moves with them. Green Gizmo in the
foreground continues bouncing — from above, his four feet lift and land in a
charming square pattern. Blue Bella's neck sways left and right, the butterfly bow
on her tail visible from above like a decorative ribbon. Red Rex's stomp leaves
new footprint impressions in the ground behind him. The parade route crowds along
the sides — jungle animal spectators wave and cheer. One parrot breaks formation
and flies forward to join the parade briefly. The sunset-rainbow sky deepens in
color. Duration 8 seconds. Grand cinematic movement.
```

---

### 📍 CLIP 24 | 3:04–3:12 | "Come and march with us today! — Close-up kids dancing!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — INTIMATE CLOSE-UP of just the four kid characters
dancing and marching together. The dinosaurs are now visible only as large colored
shapes in the deep background (vivid red, blue, and green blobs of color). This
scene focuses on the KIDS in the foreground. All four are in their most expressive
moment: Tino has his arms spread wide, mouth open singing the chorus, absolute joy.
Priya has one arm up and one to the side in a beautiful dance pose, dupatta flowing.
Arjun is in the middle of a confident dance move — knees bent, arms out, looking
cool. Starla has somehow gotten to standing (very unsteadily!) out of her cart,
both arms raised, the most triumphant baby expression ever seen. They are close
enough that we can see the delight in each character's eyes clearly. Confetti and
flower petals rain down from above. The parade road beneath their feet is covered
in colorful petals. Ultra-vibrant, CoComelon 3D quality, horizontal landscape, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, adult, nsfw, ugly, deformed, extra
limbs, bad anatomy, watermark, vertical composition, dinosaurs prominently in frame
(background only), kids not dancing (they must all be in motion), Starla sitting
(she must be standing unsteadily), muted colors, out of frame, cropped, static
characters
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the intimate kids dancing close-up: Each kid dances in their
personality style simultaneously. Tino: big sweep of arms left then right, jumping
once at 4 seconds. Priya: smooth graceful arm transitions from dance pose to pose,
her dupatta flowing with each motion. Arjun: the coolest move he can manage — a
shuffle-step that ends in a little spin. Starla STANDING: wobbles alarmingly left,
overcorrects right, finds a brief stable moment with both arms raised in triumph...
then slowly begins tipping left at 7 seconds — will she fall? The clip ends before
we know. She should be at max wobble at end of clip. Petals fall continuously
around them. Dinosaur-colored backgrounds shift slightly as those characters keep
moving. Duration 8 seconds. Pure joy and personality.
```

---

### 📍 CLIP 25 | 3:12–3:20 | "[COUNTING BRIDGE] ONE dinosaur! ONE! — Red Rex steps forward!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — CLEAR EDUCATIONAL COUNTING SCENE, Part 1. Simple,
clean composition for learning. Background is the warm Rainbow Jungle but simplified
— less cluttered, cleaner lines. CENTER FRAME: Red Rex stands ALONE, bold and
proud. He has stepped forward from where the others wait behind him — the other
two dinosaurs are clearly visible but slightly behind/faded. Bold white 3D number
"1" with golden outline floats to his upper-left — enormous, clear, easy to read.
Below the number "1", in child-friendly font: "ONE" in capital letters. Red Rex
points one tiny arm (his short T-Rex arm, comedy) at the number 1 beside him.
His other arm points at himself — "I am ONE dinosaur!" expression. Below him,
Tino holds up ONE finger clearly toward camera — modeling the counting action for
young viewers. Ultra-clean, ultra-clear educational composition. Ultra-vibrant,
CoComelon 3D quality, horizontal landscape, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, adult, nsfw, ugly, deformed, bad
anatomy, watermark, vertical composition, multiple dinos in foreground (only Red Rex
steps forward), missing number "1", crowded composition, muted colors, small number
(must be huge and clear), wrong dino in front (must be Red Rex for verse 1), out
of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the One-dinosaur counting scene: Red Rex steps one deliberate step
forward with his right leg over 2 seconds — the motion is slow and deliberate,
like he's performing for the counting lesson. His foot plants with a gentle stomp
(smaller than his parade stomp). The number "1" pulses with a golden glow, growing
10% in size then returning — a "selected" effect. Tino's finger held toward camera:
he nods his head as if saying "yes, ONE!" A bright star-burst of yellow light pulses
briefly from the number 1 at 4 seconds. Red Rex's tail wags once slowly behind
him in pride. The other two dinosaurs in the background watch politely. Blue Bella
watches with serene attention. Green Gizmo can barely contain himself — he's
bouncing very slightly in place (pre-bounce trembles). Duration 8 seconds.
```

---

### 📍 CLIP 26 | 3:20–3:28 | "TWO dinosaurs! TWO! — Blue Bella joins!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — COUNTING SCENE Part 2. Same clean educational
composition as the previous counting clip. Now RED REX is in the left-center of the
frame, and BLUE BELLA has stepped forward to join him on his right. They stand
SIDE BY SIDE (or rather, Blue Bella's body is beside him while her neck arcs much
higher). A huge "2" in bright blue with golden outline floats above them with "TWO"
below it. The contrast in size between the two dinosaurs is delightful: Red Rex is
wide and short, Blue Bella is narrow and incredibly tall. Red Rex holds up one tiny
arm (one!), and Blue Bella holds up one front leg (two!) — together modeling the
counting. In the foreground below the "2", Tino and Priya hold up 2 fingers each
toward camera — Tino's two fingers, Priya's two fingers in a graceful peace-sign
style. Clear, bright, simple educational composition. Green Gizmo waits in the
background, trembling with barely contained excitement to join. Ultra-vibrant,
CoComelon 3D quality, horizontal, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, adult, nsfw, ugly, deformed, bad
anatomy, watermark, vertical composition, only one dino (must show exactly TWO),
missing "2" number, Green Gizmo joining already (he waits), muted colors, crowded
composition, small number, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the two-dinosaur counting scene: Blue Bella is finishing her step
forward to join Red Rex — her long neck sways as she settles into position, her
feet coming to a gentle stop. The "2" number performs a bounce-in entrance from
off-frame top over 1.5 seconds, landing with a gentle "poing" effect. Red Rex
looks sideways at Blue Bella with a friendly nod. Blue Bella looks back with her
graceful amber eyes and gives a slow nod in return. The two contrasting sizes and
styles side by side create a visual comedy that needs no words. In the background,
Green Gizmo's pre-bounce trembles intensify — he's literally vibrating in place,
can barely wait. Tino and Priya hold up their two fingers steady, occasionally
looking at each other and giggling. Duration 8 seconds.
```

---

### 📍 CLIP 27 | 3:28–3:36 | "THREE dinosaurs! THREE! — ALL THREE ROAR TOGETHER! ROOAAARR!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — THE COUNTING CLIMAX: ALL THREE TOGETHER. This is
the most visually powerful counting scene. RED REX on the left, BLUE BELLA center
(neck arcing up), GREEN GIZMO launching in from the RIGHT in a magnificent JUMPING
ENTRANCE — caught in mid-air mid-bounce. A spectacular golden "3" in 3D bubble
letters with a rainbow glow floats above all three dinosaurs — enormous and bold.
"THREE!" in huge letters below it. All three dinosaurs have their mouths open in a
simultaneous ROAR — three roar-wave patterns (red, blue, green) exploding outward.
In the foreground: ALL FOUR KID CHARACTERS hold up THREE FINGERS each toward camera.
The background is an explosion of celebration: rainbow streamers, golden stars,
confetti. This is the most information-rich and joyful frame of the entire video —
the ultimate counting payoff. Ultra-vibrant, MAXIMUM celebration energy, CoComelon
3D quality, horizontal landscape, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, less than three dinos
(all three required), missing "3" number, kids not holding up 3 fingers, muted
colors, quiet composition (must be explosive), out of frame, cropped, Green Gizmo
on the ground already (he should be mid-jump entrance)
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the three-dinosaur climax: GREEN GIZMO completes his jumping entrance,
landing with the biggest BOING of the video — the impact sends a ring of energy
outward from his landing spot across the ground. The "3" number appears in a
spectacular burst-in: it starts as a tiny point at the very center of the frame and
rapidly expands to full enormous size in 1 second, accompanied by a golden sparkle
explosion. ALL THREE roar simultaneously — their three-color sound waves expand
together, creating the rainbow interference pattern seen in Clip 21 but BIGGER and
MORE SPECTACULAR. The four kids' three-finger gestures hold steady and confident.
The celebration elements (streamers, stars, confetti) are all at maximum. This 8-
second clip should feel like the emotional apex of the entire video. Duration 8 sec.
EPIC ENERGY — The most visually spectacular clip.
```

---

### 📍 CLIP 28 | 3:36–3:44 | "[GRAND FINALE CHORUS] RED! BLUE! GREEN! Hip Hip Hip HOORAY!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — GRAND FINALE composition. All characters in one
spectacular tableau. The three dinosaurs are arranged in a SEMICIRCLE framing the
four kid characters who stand in the center-foreground. RED REX rears up slightly
on his back legs (safe, controlled, majestic) on the left. BLUE BELLA's neck arcs
majestically overhead in the center-top, her head at the very top of the frame.
GREEN GIZMO is at maximum bounce height on the right, frozen at the apex of his
biggest jump. THE KID CHARACTERS in the center: Tino, Priya, and Arjun stand in
a line from left to right, each pointing at one dinosaur (Tino → Red Rex, Arjun →
Blue Bella, Priya → Green Gizmo). Starla is center-front, arms raised, face in
pure baby bliss. Above everything: a RAINBOW EXPLOSION fills the sky — not just
an arc but a BURST of rainbow from the center of the sky, rays of color fanning
outward in every direction. The words "RED! BLUE! GREEN!" float in bold matching
colors. This is the most beautiful frame of the entire video. Masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, scary, adult, nsfw, ugly, deformed,
extra limbs, bad anatomy, watermark, vertical composition, not all 7 characters
present, muted colors, plain sky (must have rainbow explosion), small characters,
unclear which kid points at which dino, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the grand finale tableau: The rainbow sky burst continues expanding
outward — color rays extending from center toward all frame edges slowly. The three
color text labels "RED! BLUE! GREEN!" pulse in their respective colors rhythmically
(0.5 seconds between each): RED pulses, then BLUE, then GREEN, then all three pulse
together. Red Rex (rearing up) slowly settles back to all fours — the controlled
descent is slow and dignified. Blue Bella's neck above sweeps one graceful arc left
to right. Green Gizmo descends from his apex bounce and lands at right side of
frame. The kid characters' pointing gestures are animated: each turns to the camera
for a moment of direct address, then turns back to point. Starla at center spins
one slow full rotation with arms up. Duration 8 seconds. The most beautiful 8 sec
of the video.
```

---

### 📍 CLIP 29 | 3:44–3:52 | "HIP HIP HIP HOORAY! — Ultimate celebration!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — ULTIMATE CELEBRATION FINAL IMAGE. The most
explosion of joy in the entire video. All seven characters are in their PEAK JOY
expressions simultaneously: Red Rex has his arms raised as high as his T-Rex arms
will go (waist height — comedy) with the biggest grin. Blue Bella has her neck
swooping in a joyful arc with her eyes finally opened to MAXIMUM width. Green Gizmo
is at the absolute peak of his highest bounce of the entire video — airborne and
fully extended upward, flower garlands flying. The four kids: Tino jumping with both
arms up, Priya spinning with dupatta flying in a full 360 arc, Arjun doing a
triumphant fist-pump jump, Starla back in her cart which is spinning in a full
circle by itself. ABOVE ALL OF THIS: the sky is a spectacular GOLDEN HOUR sunset
combined with rainbow — warm orange-gold light flooding from the right side, the
rainbow fully arced. GOLDEN CONFETTI rains from the sky in sheets. Every single
element is moving, glowing, celebrating. Ultra-vibrant, CoComelon 3D quality, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, calm/quiet (must be MAXIMUM
celebration energy), adult, nsfw, ugly, deformed, extra limbs, bad anatomy,
watermark, vertical composition, any character looking sad or neutral, static poses,
missing any of the seven characters, muted colors, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the ultimate celebration scene: This clip should have the MOST motion
of any clip in the video. All seven characters animate simultaneously at peak energy:
Red Rex's waist-high raised arms quiver with excitement, his flower crown raining
petals. Blue Bella's neck sweeps left to right in a full graceful arc over the 8
seconds. Green Gizmo at the top of his bounce slowly descends (he started mid-air)
— his descent is extremely slow (higher = slower in cartoon physics) so he barely
moves downward in 8 seconds. Kids: Tino's jump lands and he immediately jumps again.
Priya's spin completes at 3 seconds, she starts another. Arjun's fist-pump repeats
3 times. Starla's cart spins — she's loving it. Golden confetti fills the frame,
raining down everywhere. One large golden star bursts from the center at 5 seconds.
Duration 8 seconds. ABSOLUTE MAXIMUM JOY.
```

---

### 📍 CLIP 30 | 3:52–4:00 | "[OUTRO] Bye bye Red Rex! Bye bye Blue Bella! Bye bye Green Gizmo!"

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — WARM EMOTIONAL GOODBYE SCENE. The three dinosaurs
are turning and slowly walking AWAY from camera, into the beautiful Rainbow Jungle
in the background. They are seen from behind, walking away: Red Rex's broad red
back and swinging tail on the left; Blue Bella's long graceful neck and swaying
tail-bow in the center; Green Gizmo bouncing away on the right. Each dinosaur turns
their head BACK toward camera one final time in a glance over the shoulder — warm
goodbye expressions visible in that glance. All three look back simultaneously. In
the foreground, the four kid characters WAVE GOODBYE: Tino waving with his whole
arm, Priya with both hands in a Namaste bow, Arjun with a cool two-finger wave,
Starla waving both tiny fists. Their expressions are warm but slightly sad-happy —
the goodbye feeling. Above them, gentle golden text: "See you next time! 🌈" in warm
Fredoka One style. The Rainbow Jungle stretches beautifully ahead of the departing
dinosaurs into a magical misty distance. Warm golden sunset lighting. CoComelon 3D
quality, horizontal landscape, emotionally warm, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:**
```
blurry, low quality, realistic, anime, 2D, dark, abrupt ending (must feel warm and
complete), adult, nsfw, ugly, deformed, extra limbs, bad anatomy, watermark, vertical
composition, dinosaurs walking toward camera (they must be walking AWAY, backs to
viewer), missing any characters, muted colors, cold lighting, out of frame, cropped
```

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the goodbye scene: The three dinosaurs walk slowly away from camera
into the jungle — their backs to us. Red Rex's wide red back sways gently with each
stomp-step. Blue Bella's neck curves downward as she walks away, butterfly bow on
tail swaying. Green Gizmo bounces away — even from behind his bounce is identifiable.
At 5 seconds, all three turn their heads simultaneously to look back over their
shoulders — this is the most emotionally resonant moment: three magnificent, joyful
dinosaur faces gazing back at the viewer one final time. The glance holds for 2
seconds, then they turn forward and continue walking away, gradually getting smaller.
The kid characters' waves are gentle and continuous throughout. The golden text
"See you next time!" fades gently in. The Rainbow Jungle ahead glows with soft
magical light. Duration 8 seconds. Warm, complete, emotionally satisfying ending.
```

---

## BUFFER CLIPS (31–35) — Audio Sync Cushions

### 📍 CLIP 31 [BUFFER] — Extra Parade Wide Shot

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 landscape — a beautiful still-life style full parade scene.
All characters present: three dinosaurs and four kids marching along the parade
route. The composition is balanced and gorgeous — each character clearly visible.
This is the "poster shot" of the video — if you had to pick ONE image to represent
the entire video, this would be it. Rainbow fills the sky perfectly. Confetti
gently falling. Maximum saturation. CoComelon 3D quality, masterpiece, 4K.
```

**🚫 NEGATIVE PROMPT:** [Use Universal Negative Prompt from Character Design Bible]

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the poster parade shot: All characters in gentle motion — Rex
stomping, Bella swaying, Gizmo bouncing, kids marching. Speed of all motions is
50% of normal — a more stately, majestic version of the parade march, suitable as
a buffer clip for any section of the video. Duration 8 seconds.
```

---

### 📍 CLIP 32 [BUFFER] — Character Close-Up Rotation

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 — four close-up portraits of each kid character arranged in
a 2x2 grid: Tino (top-left, huge grin), Priya (top-right, singing expression),
Arjun (bottom-left, confident smirk), Starla (bottom-right, clapping giggle).
All in their signature expressions. Colorful background gradient behind each.
Ultra-vibrant, CoComelon 3D quality, 4K.
```

**🚫 NEGATIVE PROMPT:** [Use Universal Negative Prompt]

**🎬 VIDEO ANIMATION PROMPT:**
```
Starting from the 2x2 character grid: Each character's portrait gently animates
in its cell — Tino waves, Priya tilts her head in song, Arjun raises one eyebrow,
Starla claps twice. A colored border glows around each cell sequentially (Tino →
Priya → Arjun → Starla) in a 2-second loop. Duration 8 seconds.
```

---

### 📍 CLIP 33 [BUFFER] — Rainbow Color Recap Screen

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 — clean educational recap screen. Three large colored circles
from left to right: vivid red circle with Red Rex's face inside, bright blue circle
with Blue Bella's face inside, vibrant green circle with Green Gizmo's face inside.
Below each circle: "RED / சிவப்பு / लाल" — the color name in English, Tamil, and Hindi
(bilingual bonus). Large "1 2 3" numbers above each circle. The background is clean
white with gentle rainbow glow. Ultra-vibrant, educational, CoComelon 3D quality, 4K.
```

**🚫 NEGATIVE PROMPT:** [Use Universal Negative Prompt]

**🎬 VIDEO ANIMATION PROMPT:**
```
The three color circles gently pulse in turn: red circle brightens, then blue, then
green, then all three together. The numbers 1, 2, 3 above each circle bounce
gently on a loop. The dinosaur face thumbnails within each circle blink once each
at different times. Duration 8 seconds. Pure educational buffer.
```

---

### 📍 CLIP 34 [BUFFER] — Starla Solo Reaction to Everything

**🖼️ IMAGE PROMPT:**
```
Close-up wide horizontal 16:9 — just Starla in center frame, in her most iconic
reaction to the dinosaurs: both hands pressed to her chubby cheeks, eyes enormous
circles, mouth a perfect O of pure awe. All three dinosaur silhouettes are visible
in soft bokeh behind her — red, blue, and green shapes suggesting the three dinos
stand around her. Golden stars float around her head. Maximum cute factor.
Ultra-vibrant, CoComelon 3D quality, 4K.
```

**🚫 NEGATIVE PROMPT:** [Use Universal Negative Prompt + "Starla looking sad or scared (must be amazed)"]

**🎬 VIDEO ANIMATION PROMPT:**
```
Starla's O-mouth slowly transitions from awe to a huge toothless giggle over 4
seconds. Both hands come away from her cheeks and she begins clapping rapidly.
The three dino silhouettes in the background shift gently. Three gold sparkles
appear around her head and orbit slowly. Duration 8 seconds.
```

---

### 📍 CLIP 35 [BUFFER] — End Slate / Subscribe Card

**🖼️ IMAGE PROMPT:**
```
Wide horizontal 16:9 — TinyToons Universe subscribe screen. Deep indigo background
(#4F46E5) with golden sparkle particles. Center: all four kid characters arranged
around a giant bright red YouTube Subscribe button (3D cartoon style, glossy). Tino
points at the button with one hand and waves at camera with the other. Priya holds
up a sign saying "NEW VIDEOS EVERY WEEK! 🌈". Arjun has both thumbs up beside the
button. Starla sits on TOP of the giant subscribe button, arms raised in triumph.
Above all: "TinyToons Universe" in golden 3D bubble letters with sparkles. Bell
notification icon visible in the top-right corner glowing. Professional channel
endcard design. Ultra-vibrant, CoComelon 3D quality, 4K.
```

**🚫 NEGATIVE PROMPT:** [Use Universal Negative Prompt]

**🎬 VIDEO ANIMATION PROMPT:**
```
The subscribe button pulses with a gentle glow — growing 5% larger then returning,
on a 2-second cycle. Tino's pointing gesture alternates between pointing at the
button and waving at camera. The bell icon in the corner rotates once (like being
rung). Starla on top of the button bounces with the button's pulse. Sparkle
particles drift throughout the frame. Duration 8 seconds. Hold this as the end
slate for 5-10 seconds in the final video.
```

---

## CAPCUT EDITING TIMELINE — LONG VIDEO

```
CAPCUT PROJECT SETUP:
New Project → 16:9 horizontal → 3840×2160 (4K) if phone supports, else 1920×1080
Frame Rate: 24fps (cinematic) or 30fps
Export: Highest quality MP4, max bitrate

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VIDEO CLIP TRACK — SEQUENCE (30 clips × 8 seconds = 240 sec = 4:00 min)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[0:00–0:08]   Clip 01 — Intro title card          8 sec
[0:08–0:16]   Clip 02 — Red Rex reveal            8 sec
[0:16–0:24]   Clip 03 — Red color education       8 sec
[0:24–0:32]   Clip 04 — Stomp/Whomp action        8 sec
[0:32–0:40]   Clip 05 — Rex and kids connect      8 sec
[0:40–0:48]   Clip 06 — Pre-chorus roar           8 sec
[0:48–0:56]   Clip 07 — Parade starts             8 sec
[0:56–1:04]   Clip 08 — Parade faces camera       8 sec
[1:04–1:12]   Clip 09 — HOORAY celebration        8 sec
[1:12–1:20]   Clip 10 — Blue Bella entrance       8 sec
[1:20–1:28]   Clip 11 — Bella sways               8 sec
[1:28–1:36]   Clip 12 — Bella above the clouds    8 sec
[1:36–1:44]   Clip 13 — Arjun/Starla react        8 sec
[1:44–1:52]   Clip 14 — Gentle roar pre-chorus    8 sec
[1:52–2:00]   Clip 15 — 2-dino parade             8 sec
[2:00–2:08]   Clip 16 — Aerial 2-dino             8 sec
[2:08–2:16]   Clip 17 — Green Gizmo entrance      8 sec
[2:16–2:24]   Clip 18 — Gizmo bouncing            8 sec
[2:24–2:32]   Clip 19 — Green education           8 sec
[2:32–2:40]   Clip 20 — Gizmo comedy portrait     8 sec
[2:40–2:48]   Clip 21 — Triple roar pre-chorus    8 sec
[2:48–2:56]   Clip 22 — 3-dino parade spectacular 8 sec
[2:56–3:04]   Clip 23 — Aerial 3-dino cinematic   8 sec
[3:04–3:12]   Clip 24 — Kids dance close-up       8 sec
[3:12–3:20]   Clip 25 — Count 1 — Red Rex         8 sec
[3:20–3:28]   Clip 26 — Count 2 — Bella joins     8 sec
[3:28–3:36]   Clip 27 — Count 3 — ALL THREE!      8 sec
[3:36–3:44]   Clip 28 — Finale tableau RED/BLUE/GREEN 8 sec
[3:44–3:52]   Clip 29 — Ultimate celebration      8 sec
[3:52–4:00]   Clip 30 — Warm goodbye              8 sec
[4:00–4:10]   Clip 35 — Subscribe endcard         10 sec (BONUS)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VOICEOVER TRACK:
Import voiceover MP3 at 0:00. Volume: 100%.
Adjust individual clip timing if voice finishes early or late.
Add [0.3 sec fade-in] and [1.0 sec fade-out at 4:00].

MUSIC TRACK:
Import Suno AI music at 0:00. Volume: 28%.
The music should be looped if it's shorter than 4 minutes.
Fade music out from 3:50 to 4:00 (10-second fade out).

SOUND EFFECTS TRACK (timestamps and sounds):
[0:00] Trumpet fanfare — 70% volume
[0:20] Cartoon bass thud ×2 — 65% volume
[0:24] Triple stomp sound ×3 — 65% volume
[0:40] Playful cartoon roar — 70% volume
[0:44] Triple stomp ×3 — 60% volume
[0:48] March drum intro — fades into music
[1:04] Kids cheer/hooray — 60% volume
[1:12] Waterfall ambience (soft, 15% vol) — plays under Bella section
[2:08] BOING spring sound (BIG) — 80% volume — Gizmo entrance!
[2:17] Smaller boing — 60% volume
[2:41] Bouncy cartoon roar — 65% volume
[3:27] TRIPLE ROAR (layered 3 sounds) — 75% volume — biggest SFX!
[3:44] Victory cheer crowd — 60% volume
[3:52] End chime bells — 50% volume

TRANSITIONS:
Clips 1–9 (Red Rex section): "Cut" transitions (snap cuts match stomp energy)
Clips 10–16 (Blue Bella section): "Dissolve" transitions (0.5 sec, smooth/graceful)
Clips 17–21 (Green Gizmo section): "Flash" or "Zoom" transitions (bouncy energy)
Clips 22–30 (Finale): "Cut" transitions (maximum energy snap cuts)

TEXT OVERLAY TRACK:
Font: Fredoka One (all text)
[0:00–0:08]   "THE RAINBOW DINOSAUR PARADE! 🌈🦕" — large, top center, golden
[0:16–0:24]   "RED" — enormous, center, vivid red color
[0:48–1:12]   "DINOSAUR PARADE! 🎉" — top strip, rotating, gold
[1:12–1:20]   "BLUE BELLA" — center, ocean blue color
[1:16–1:24]   "BLUE" — large, center, vivid blue
[2:08–2:16]   "GREEN GIZMO! 🦕" — center, forest green
[2:24–2:32]   "GREEN" — large, center, vivid green
[3:12–3:20]   "1 ONE" — huge number, red, counting bridge
[3:20–3:28]   "2 TWO" — huge number, blue
[3:28–3:36]   "3 THREE" — huge number, green — biggest text!
[3:36–3:44]   "RED! BLUE! GREEN! 🌈" — color-matching individual words
[3:44–3:52]   "HIP HIP HOORAY! 🎉" — gold, animated bounce
[3:52–4:00]   "See you next time! TinyToons Universe 🌈" — warm, golden, centered
[4:00–4:10]   Subscribe card text — "SUBSCRIBE! 🔔 New Videos Every Week!"

BURNED-IN SUBTITLES (recommended for all lyrics):
Add voiceover lyric text as karaoke-style subtitles at the bottom of the frame.
Font: Nunito Bold. Size: medium-large. White with dark blue shadow.
Each line appears as it is spoken and disappears when the next line begins.
This helps children follow along and improves learning + watch time.

CAPCUT ICING: Add "Cinematic" color grade preset to the entire video at 30% strength.
This slightly deepens the blacks and boosts the saturation warmly.
```

---

## THREE THUMBNAIL VARIANTS — A/B/C TEST

**THUMBNAIL A — "THE ROAR FACE" (Test for highest CTR)**

🖼️ THUMBNAIL PROMPT:
```
Professional YouTube thumbnail for "The Rainbow Dinosaur Parade" — 1280×720 pixels.
DOMINANT IMAGE: Red Rex's face in extreme close-up from a slight low angle (looking
up at him) — his enormous friendly mouth wide open in a HUGE roar, eyes wide and
joyful. His face fills 60% of the right side of the thumbnail. His vivid red color
is at maximum saturation. He fills the right portion. Left portion: Tino Starlight
(close-up, top-left) looking up at Rex with mouth wide open in amazed delight —
eyes enormous. Bottom center: Bold white and red text "DINOSAUR PARADE! 🦕" in
massive Fredoka One style letters with thick black outline. Background: explosive
electric yellow and orange starburst pattern. Top-left corner: small "TinyToons
Universe" logo badge. Three small colored circles bottom-right: red, blue, green.
Ultra-vibrant, maximum saturation, professionally designed, instantly click-worthy
kids thumbnail, 4K quality.
```

---

**THUMBNAIL B — "ALL THREE DINOS" (Test for content curiosity)**

🖼️ THUMBNAIL PROMPT:
```
Professional YouTube thumbnail 1280×720. Shows all THREE dinosaurs in a row (small
but all visible): vivid red Red Rex on left stomping, ocean blue Blue Bella in
center with neck arcing, vibrant green Green Gizmo on right mid-bounce. All three
facing camera with their signature expressions — Rex's huge grin, Bella's graceful
smile, Gizmo's goofy tongue-out face. In front of them, tiny Tino waves up at the
viewer. Bold title text: "🌈 3 DINOSAUR COLORS! 🦕" in chunky white letters with
colored shadows (red, blue, green). Background: deep rich gradient blue-to-purple
sky with rainbow arc across the top. Bottom: thick yellow stripe with
"TinyToons Universe" text. Three color circles: RED | BLUE | GREEN labeled.
Ultra-vibrant, CoComelon quality 3D render, professional kids thumbnail, 4K.
```

---

**THUMBNAIL C — "STARLA'S REACTION" (Test for baby content algorithm)**

🖼️ THUMBNAIL PROMPT:
```
Professional YouTube thumbnail 1280×720. DOMINANT IMAGE: Starla the baby (enormous
chubby face, single curl, yellow star onesie, massive round eyes in shock-delight
expression — mouth O-shaped, hands pressed to cheeks) fills the LEFT 55% of the
thumbnail in extreme close-up. RIGHT side: Red Rex's friendly grinning face appears
from behind Starla — enormous compared to her, almost popping out from the right
edge of the thumbnail. The size contrast between the baby and dinosaur is comedy
gold. Bold text in center-bottom: "BABY MEETS DINOSAUR! 😱🦕" in Fredoka One white
with thick black outline. Background: bright rainbow gradient — warm and inviting.
Top badge: "TinyToons Universe". Ultra-vibrant, maximum cute-factor, CoComelon
3D quality, most likely to go viral on baby content algorithm, 4K.
```

> **WHICH THUMBNAIL TO TEST:** Upload Thumbnail A first (upload day 1). After
> 48 hours, switch to Thumbnail B and compare CTR in YouTube Studio Analytics.
> After another 48 hours, if Thumbnail B performs better, test C. Keep whichever
> has the highest CTR after 6 days. This is the free A/B testing method.

---

## COMPLETE YOUTUBE METADATA

**✅ COPY-READY TITLE (A/B test two titles):**
```
TITLE A: The Rainbow Dinosaur Parade! 🌈🦕 | Colors Song | RED BLUE GREEN | TinyToons Universe
TITLE B: 3 DINOSAUR COLORS! 🦕 | RED BLUE GREEN Song for Kids | TinyToons Universe
```

**✅ COPY-READY DESCRIPTION (Copy everything below the line):**
```
─────────────────────────────────────────────────────────
🦕 Welcome to the RAINBOW DINOSAUR PARADE! 🌈

Join Tino, Priya, Arjun, and baby Starla as they meet THREE amazing dinosaur
friends — RED REX the stomping T-Rex, BLUE BELLA the graceful Brachiosaurus, and
GREEN GIZMO the bouncing Triceratops! 🦕🦕🦕

In this fun 3D animated song, your little ones will learn:
✅ The color RED — red apples, red roses, red fire trucks!
✅ The color BLUE — blue sky, blue ocean, blue waterfall!
✅ The color GREEN — green leaves, green frogs, green trees!
✅ Counting 1, 2, 3 with the dinosaurs!
✅ Stomping, swaying, and bouncing movements!

🌈 Perfect for toddlers and preschoolers aged 2–8 years!
🎵 Catchy songs that kids will love to sing along!
🦕 Original 3D animated characters — Red Rex, Blue Bella & Green Gizmo!
👶 Baby Starla's reactions will make you smile every time!

📺 Watch and Learn with TinyToons Universe — your child's favorite place for:
→ Nursery Rhymes | ABC Songs | Counting Songs
→ Color Songs | Animal Songs | Action Songs
→ Telugu Songs | Tamil Songs | Hindi Songs | Odia Songs | English Songs

🔔 SUBSCRIBE and hit the BELL so you never miss a new video!
📱 New videos every week! Tell your little ones!

━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏰ VIDEO CHAPTERS (click to jump):
0:00 - The Rainbow Dinosaur Parade Begins! 🌈
0:08 - Meet RED REX! 🔴🦕
0:48 - DINOSAUR PARADE Chorus 🎉
1:12 - Meet BLUE BELLA! 🔵🦕
1:52 - DINOSAUR PARADE Chorus #2 🎉
2:12 - Meet GREEN GIZMO! 🟢🦕
2:48 - DINOSAUR PARADE Chorus #3 🎉🎉
3:12 - Count 1, 2, 3 with the Dinosaurs! 🔢
3:32 - GRAND FINALE PARADE! 🏆
3:52 - Goodbye from the Dinosaurs! 👋
━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏷️ About TinyToons Universe:
TinyToons Universe creates premium 3D animated kids songs and nursery rhymes in
English, Telugu, Tamil, Hindi, and Odia — serving families across the US and India!
Our characters Tino, Priya, Arjun, and baby Starla love to learn, sing, and explore!

👨‍👩‍👧 Safe, COPPA-compliant, educational content for young children.

#TinyToonsUniverse #DinosaurSong #ColorSong #KidsSongs #NurseryRhymes
─────────────────────────────────────────────────────────
```

**✅ COPY-READY TAGS (35 tags):**
```
tinytoons universe, dinosaur song for kids, dinosaur colors song, red blue green
song, colors song for kids, color learning song, preschool songs, kids songs 2025,
3d animated kids songs, nursery rhymes 3d animation, toddler learning colors, red
rex dinosaur, blue bella dinosaur, green gizmo dinosaur, rainbow dinosaur, kids
dinosaur cartoon, CoComelon style songs, educational songs for kids, counting song
1 2 3, count with dinosaurs, dinosaur parade song, kids songs english, animated
nursery rhymes, children songs dinosaur, baby songs learning, toddler songs, kids
youtube channel, dinosaur kids video, color songs for preschool, learn colors kids,
3d animation kids, kids learning video, english songs for children, tinytoons,
dinosaur cartoon kids
```

**✅ HASHTAGS:**
```
#TinyToonsUniverse #DinosaurSong #ColorSong #KidsSongs #NurseryRhymes
#3DAnimation #ChildrenSongs #ToddlerLearning #PreschoolSong #LearnColors
#RedBlueGreen #DinosaurKids #BabySongs #KidsYouTube #EducationalKids
```

**✅ UPLOAD SETTINGS:**
```
Category: Education
Made for Kids: YES ✓
Visibility: Public (schedule for Monday 2:00 PM EST / 7:30 PM IST)
Playlist: Add to "English Songs" + "Learn Colors" + "Dinosaur Songs" playlists
End Screen: Add at 3:45 — link to Channel Page + Most recent video
Cards: Add at 2:00 — link to "ABC Song" or next video
Chapters: Add chapter timestamps from description above ✓
Subtitles: Enable auto-generated English captions then review accuracy
```

---

## 5 YOUTUBE SHORTS CUTS FROM THIS LONG VIDEO

```
CUT 1: "RED REX ROAR CHALLENGE" — Short
→ Trim: 0:40 to 1:12 (32 seconds)
→ Format: Crop to 9:16 vertical in CapCut (focus on characters)
→ Title: "Can You Roar Like RED REX? 🦕🔴 | TinyToons Universe #Shorts"
→ Hook: Pre-chorus roar scene → chorus parade → HOORAY
→ Add caption at top: "ROAR CHALLENGE! 🦕"

CUT 2: "BLUE BELLA ABOVE THE CLOUDS" — Short
→ Trim: 1:12 to 1:52 (40 seconds)
→ Title: "Blue Bella Goes ABOVE THE CLOUDS! 🦕💙 | TinyToons Universe #Shorts"
→ Hook: Entrance → clouds reveal → kids react
→ Add caption: "HOW HIGH CAN SHE GO? ☁️"

CUT 3: "GREEN GIZMO BOUNCING CHALLENGE" — Short
→ Trim: 2:08 to 2:48 (40 seconds)
→ Title: "Green Gizmo CAN'T STOP BOUNCING! 🦕💚 | TinyToons Universe #Shorts"
→ Hook: Explosive BOING entrance → bouncing forest → pre-chorus
→ Add caption: "BOING BOING BOING! 🦕"

CUT 4: "COUNT 1-2-3 WITH DINOSAURS" — Short
→ Trim: 3:12 to 3:36 (24 seconds)
→ Title: "Count 1-2-3 with Dinosaurs! 🦕🌈 | TinyToons Universe #Shorts"
→ Hook: Count 1 → Count 2 → Count 3 → TRIPLE ROAR
→ Add big overlay numbers: 1... 2... 3!

CUT 5: "STARLA MEETS THE DINOSAURS" — Short
→ Trim: 1:36 to 2:08 (32 seconds) — Starla reaction focus
→ Title: "Baby Starla's First Dinosaur! 👶🦕 | TinyToons Universe #Shorts"
→ Hook: Starla's joy tear → Arjun's amazement → Gizmo's entrance
→ Zoom in on Starla in CapCut to make her face prominent
→ Most likely to go viral (baby + dinosaur = maximum engagement)
```

---

## PRODUCTION SEQUENCE — DO THESE IN ORDER

```
WEEK BEFORE UPLOAD (Day-by-Day Plan):

DAY 1 (TODAY):
□ Generate all 3 dinosaur character reference images (Red Rex, Blue Bella, Green Gizmo)
□ Generate the 4 kid character reference images (use existing Bible prompts)
□ Generate Rainbow Jungle background reference
□ Save all reference images to a dedicated folder: "TTU_Dinosaur_Parade_References"

DAY 2:
□ Generate Clips 01-10 images (one by one, use reference images for consistency)
□ After every 5 images, compare with reference to check character consistency
□ Save all images named: "TTU_DinoParade_Scene01.png" through "..._Scene10.png"

DAY 3:
□ Generate Clips 11-20 images
□ Save named consistently

DAY 4:
□ Generate Clips 21-30 images + 5 buffer images
□ Generate all 3 thumbnail variants

DAY 5:
□ Generate all video animations (upload Scene01 image to Kling AI → paste
  corresponding video prompt → download → name "TTU_DinoParade_Video01.mp4")
□ Do this for all 35 clips (Kling AI or Pika Labs, free tier)

DAY 6:
□ Generate voiceover audio in ElevenLabs using the complete script
□ Generate background music in Suno AI using the music prompt
□ Download all sound effects from Freesound.org

DAY 7:
□ Edit in CapCut following the timeline above
□ Add text overlays, transitions, subtitles
□ Export at maximum quality
□ Generate thumbnail in Canva (use AI-generated thumbnail image + Fredoka One text)
□ Upload to YouTube with complete metadata

UPLOAD SCHEDULE:
Monday 2:00 PM EST (7:30 PM IST) — Long Video
Wednesday 8:00 AM EST — Short Video 1 (Superhero)
Tuesday 6:00 PM IST — Short Video 2 (Tamil Colors)
```

---

*END OF PART 3 — LONG VIDEO*
*END OF COMPLETE TINYTOONS UNIVERSE PRODUCTION PACKAGE*
*Total: Character Design Bible (Part 1) + 2 Short Videos (Part 2) + 1 Long Video (Part 3)*
*All prompts are copy-paste ready. Generate images one scene at a time. You can do this!*
